/* eslint-disable import/no-extraneous-dependencies */
require('dotenv').config();
const merge = require('webpack-merge');
const baseConfig = require('./webpack.common.js');
const Path = require('path');
const HtmlWebpackPlugin = require('html-webpack-plugin');
const Webpack = require('webpack');

console.log('env ', JSON.stringify(process.env.FIREBASE_API_KEY));

module.exports = merge(baseConfig, {
  mode: 'development',

  devtool: 'source-map',
  devServer: {
    contentBase: Path.resolve(__dirname, '../'),
    hot: true,
    inline: true,
    historyApiFallback: true
  },
  module: {
    rules: [
      { test: /\.(jpe?g|png|gif)$/,
        use: ['file-loader', 'image-webpack-loader']
      },
      {
        test: /\.woff2?(\?v=\d+\.\d+\.\d+)?$/,
        use: ['file-loader?name=[name].[ext]']
      }
    ] },
  plugins: [
    new HtmlWebpackPlugin({
      path: '',
      template: Path.resolve(__dirname, '../src/index.html')
    }),
    new Webpack.DefinePlugin({
      'process.env': {
        NODE_ENV: JSON.stringify('development'),
        FIREBASE_API_KEY: JSON.stringify(process.env.FIREBASE_API_KEY),
        FIREBASE_AUTH_DOMAIN: JSON.stringify(process.env.FIREBASE_AUTH_DOMAIN),
        FIREBASE_DATABASE_URL: JSON.stringify(process.env.FIREBASE_DATABASE_URL),
        FIREBASE_STORAGE_BUCKET: JSON.stringify(process.env.FIREBASE_STORAGE_BUCKET)
      }
    }),
    new Webpack.HotModuleReplacementPlugin()
  ]
});
