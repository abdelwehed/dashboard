/* eslint-disable import/no-extraneous-dependencies */
require('dotenv').config();
const Path = require('path');
const Webpack = require('webpack');
const ExtractTextPlugin = require('extract-text-webpack-plugin');
const WebpackVersionFilePlugin = require('webpack-version-file-plugin');
const UglifyJsPlugin = require('uglifyjs-webpack-plugin');

console.log('path ', Path.resolve(__dirname, '../public'));
module.exports = {

  entry: {
    app: Path.resolve(__dirname, '../src/app/index.jsx'),
    vendor: [
      'jquery',
      'lodash',
      'react',
      'react-dom',
      'react-ga',
      'react-helmet',
      'react-redux',
      'react-router',
      'react-router-redux',
      'redux',
      'redux-thunk'
    ]
  },
  output: {
    path: Path.resolve(__dirname, '../public'),
    publicPath: process.env.HOSTING_URL || '',
    filename: '[name].js'
  },
  resolve: {
    extensions: ['.js', '.jsx']
  },
  module: {
    rules: [{
      test: /.jsx?$/,
      use: 'eslint-loader',
      enforce: 'pre',
      include: Path.resolve(__dirname, '../src'),
      exclude: /node_modules/
    }, {
      test: /.jsx?$/,
      include: Path.resolve(__dirname, '../src/app'),
      use: 'babel-loader',
      exclude: /node_modules/
    }, {
      test: /\.css$/,
      use: [
        'style-loader',
        'postcss-loader',
        'css-loader'
      ],
      include: [/fonts/]
    },
    {
      test: /\.scss$/,
      use: ExtractTextPlugin.extract({
        fallback: 'style-loader',
        use: ['css-loader', 'sass-loader']
      })
    }, {
      test: /\.svg$/,
      loader: 'svg-sprite-loader',
      options: {
        runtimeCompat: true
      }
    }, // Font files
    {
      test: /\.(woff|woff2|ttf|otf)$/,
      loader: 'file-loader',
      include: [/fonts/],

      options: {
        name: '[hash].[ext]',
        outputPath: 'css/',
        publicPath: url => `../scc/${url}`
      }
    }
    ]
  },
/*   optimization: {
    runtimeChunk: 'single',
    splitChunks: {
      chunks: 'all',
      maxInitialRequests: Infinity,
      minSize: 0,
      cacheGroups: {
        vendor: {
          test: /[\\/]node_modules[\\/]/,
          name(module) {
            // get the name. E.g. node_modules/packageName/not/this/part.js
            // or node_modules/packageName
            const packageName = module.context.match(/[\\/]node_modules[\\/](.*?)([\\/]|$)/)[1];

            // npm package names are URL-safe, but some servers don't like @ symbols
            return `npm.${packageName.replace('@', '')}`;
          }
        }
      }
    }
  } */
  plugins: [
    new Webpack.HashedModuleIdsPlugin(), // so that file hashes don't change unexpectedly
    new ExtractTextPlugin({
      filename: 'styles/[name].[hash].css',
      disable: false,
      allChunks: true
    }),
    new WebpackVersionFilePlugin({
      packageFile: Path.join(__dirname, '../package.json'),
      template: Path.join(__dirname, '../version.ejs'),
      outputFile: Path.join(__dirname, '../static/version.json')
    })
  ]
};
