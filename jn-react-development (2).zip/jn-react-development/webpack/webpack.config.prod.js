/* eslint-disable import/no-extraneous-dependencies */
require('dotenv').config({ path: '../.env' });
const merge = require('webpack-merge');
const baseConfig = require('./webpack.common.js');
const Webpack = require('webpack');
const Path = require('path');
const HtmlWebpackPlugin = require('html-webpack-plugin');
const CopyWebpackPlugin = require('copy-webpack-plugin');


module.exports = merge(baseConfig, {

  mode: 'production',
  devtool: 'source-map',
  output: {
    filename: 'scripts/[name].[chunkhash].js'
  },
  module: {
    rules: [
      { test: /\.(jpe?g|png|gif)$/,
        use: [
          {
            loader: 'file-loader',
            query: {
              limit: 40000,
              name: process.env.HOSTING_URL
                        ? `${process.env.HOSTING_URL}/static/img/[name].[hash].[ext]`
                        : '/static/img/[name].[hash].[ext]'
            }
          },
          'image-webpack-loader'
        ]
      },
      {
        test: /\.woff2?(\?v=\d+\.\d+\.\d+)?$/,
        use: ['file-loader?name=[name].[ext]']
      }
    ]
  },
  plugins: [
    new HtmlWebpackPlugin({
      path: process.env.HOSTING_URL
        ? process.env.HOSTING_URL
        : '/',
      template: Path.resolve(__dirname, '../src/index.html')
    }), new CopyWebpackPlugin([
      {
        from: '../static',
        to: 'static'
      }
    ]),
    new Webpack.DefinePlugin({
      'process.env': {
        NODE_ENV: JSON.stringify('production'),
        FIREBASE_API_KEY: JSON.stringify(process.env.FIREBASE_API_KEY),
        FIREBASE_AUTH_DOMAIN: JSON.stringify(process.env.FIREBASE_AUTH_DOMAIN),
        FIREBASE_DATABASE_URL: JSON.stringify(process.env.FIREBASE_DATABASE_URL),
        FIREBASE_STORAGE_BUCKET: JSON.stringify(process.env.FIREBASE_STORAGE_BUCKET)
      }
    })
  ]
});
