import React from 'react';
import ReactDOM from 'react-dom';
import { Provider } from 'react-redux';
import { Router, Route, IndexRoute } from 'react-router';
import ReactGA from 'react-ga';
import firebase from 'firebase';
import { ADMIN_LEVEL } from './core/constants/constants';
import store, { history } from './store';
import './bundle.scss';
import App from './core/app';
import Home from './themes/JN/pages/home/home';
import Dashboard from './themes/JN/pages/dashboard/dashboard';
import AccountSettings from './themes/JN/pages/account/settings';
import AccountNotifications from './themes/JN/pages/account/notifications';
import Listing from './themes/JN/pages/listing/listing';
import Page from './themes/JN/pages/page/page';
import Post from './themes/JN/pages/post/post';
import Course from './themes/JN/pages/course/course';
import course from './themes/JN/pages/course2/course';
import Subject from './themes/JN/pages/subject/subject';
import Module from './themes/JN/pages/module/module';
import Activity from './themes/JN/pages/activity/activity';
import NotFound from './themes/JN/pages/notFound/notFound';
import Admin from './core/admin/admin';
import Signup from './themes/JN/components/signin/signin';
import SignIn from './themes/JN/pages/singin/signin';

// Google Analytics initializacion
ReactGA.initialize('UA-139155641-1', {
  debug: false,
  titleCase: false,
  gaOptions: {}
});


function logPageView() {
  if (process.env.NODE_ENV === 'production') {
    ReactGA.set({ page: window.location.href });
    ReactGA.pageview(window.location.href);
  }
}

function requireBuy(nextState, replace, callback) {
  if (store.getState().firebase.data.lessons == null) {
    history.goBack();
  } else {
    callback();
  }
  console.log('index props ', store.getState().firebase.data.lessons);
}
function requireAuth(nextState, replace, callback) {
  firebase.auth().onAuthStateChanged((user) => {
    if (!user || !user.emailVerified) {
     // this.props.setNotification({ message: 'need to login', type: 'error' });
     // TopNav.showForm();
      history.push('joinus');
      console.log('not logged ');
    } else {
      let requiresLevel = 0;
      nextState.routes.map((route) => {
        if (route.level) {
          requiresLevel = route.level;
          console.log('level ', route.level);
        }
        return false;
      });
      if (requiresLevel > 0) {
        firebase.database().ref(`/users/${user.uid}`).once('value').then((snapshot) => {
          if (!snapshot.val() || !snapshot.val().info.level || (snapshot.val().info.level < requiresLevel)) {
            history.goBack();
          } else {
            callback();
          }
        });
      } else {
        console.log('test ');
        callback();
      }
    }
  });
}

// Router initialization
ReactDOM.render(
  <Provider store={store}>
    <Router
      onUpdate={() => {
        window.scrollTo(0, 0);
        logPageView();
      }} history={history}
    >
      <Route path="/" component={App}>
        <IndexRoute component={Home} />
        <Route path="dashboard" component={Dashboard} onEnter={requireAuth} />
        <Route path="account" component={AccountSettings} onEnter={requireAuth} />
        <Route path="login" component={Signup} />
        <Route path="account/notifications" component={AccountNotifications} onEnter={requireAuth} />
        <Route path="courses" component={Listing} />
        <Route path="courses/:slug" component={course} />
        <Route path="courses/:slug/:lessonslug" component={course} onEnter={requireBuy} />
        <Route path="courses/:slug/register" component={Course} />
        <Route path="courses/:slug/subjects" component={Course} />
        <Route path="courses/:slug/fees" component={Course} />
        <Route path="courses/:slug/requirements" component={Course} />
        <Route path="subjects" component={Listing} />
        <Route path="subjects/:slug" component={Subject} />
        <Route path="subjects/:slug/modules" component={Subject} />
        <Route path="subjects/:slug/activities" component={Subject} />
        <Route path="modules" component={Listing} />
        <Route path="modules/:slug" component={Module} />
        <Route path="activities" component={Listing} />
        <Route path="activities/:slug" component={Activity} />
        <Route path="blog" component={Listing} />
        <Route path="blog/:slug" component={Post} />
        <Route path="about" component={Page} />
        <Route path="about/jobs" component={Page} />
        <Route path="about/contact" component={Page} />
        <Route path="admin" component={Admin} level={ADMIN_LEVEL} onEnter={requireAuth} />
        <Route path="admin/:type/:action" component={Admin} level={ADMIN_LEVEL} onEnter={requireAuth} />
        <Route path="admin/:type/:action/:slug" component={Admin} level={ADMIN_LEVEL} onEnter={requireAuth} />
        <Route path="joinus" component={SignIn} />
        <Route path="*" component={NotFound} />
      </Route>
    </Router>
  </Provider>, document.getElementById('react-root')
);
