/* eslint-disable jsx-a11y/href-no-hash */
import React from 'react';
import $ from 'jquery';
import { Link } from 'react-router';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import includes from 'lodash/includes';
import IronImage from '../common/lib/ironimage/ironImage';
import placeholder from '../../../../static/img/logo-big.jpg';
// CSS3 animation helper to cleanup classes after animationd ends
$.fn.extend({
  animateCss(animationName, callback) {
    const animationEnd = 'webkitAnimationEnd mozAnimationEnd MSAnimationEnd oanimationend animationend';
    $(this).addClass(`animated ${animationName}`).one(animationEnd, () => {
      $(this).removeClass(`animated ${animationName}`);
      if (callback) {
        callback();
      }
    });
  }
});

// String capitalization
String.prototype.capitalize = () => (this ? this.charAt(0).toUpperCase() + this.slice(1) : null);

// Common app methods
module.exports = {


  renderCards: (type, props, search = '') => {
    let newList = [];
    const path = 'courses';
    let iscourse = true;
    let ishorizontal = false;
    const lessons = props.courses.lessons;
    let card = String;
    let list = [];
    if (type === 'blog') {
      type = 'posts';
      card = 'is-post is-horizontal';
      iscourse = false;
      ishorizontal = true;
    } else if (type === 'courses') {
      card = 'is-course';
      iscourse = true;
      ishorizontal = false;
    } else {
      card = 'is-course';
      iscourse = false;
      ishorizontal = false;
    }
    newList = Object.keys(props[type]).map((key) => {
      let item;
      let date;
      if (props[type][key].title.toLowerCase().indexOf(search.toLowerCase()) !== -1) {
        item = props[type][key];
        date = (type === 'courses')
        ? item.startDate
        : item.date;
      }
      list = item.lessons;


      if (item && item.status && item.status !== 'inactive') {
        return (
          <div key={key} className="column is-4-fullhd is-4-desktop is-6-tablet">
            <div className={`card is-jn ${card}`}>
              <CardHeader course={item} lessons={item.lessons} path={`/${path}`} item={item} featuredImage={item.featuredImage} slug={`/${item.slug}`} title={item.title} type={iscourse} />
              {
                        ishorizontal ?
                          <HorizontalCard
                            date={date}
                            title={item.title}
                            path={`/${path}`}
                            slug={`/${item.slug}`}
                            type={iscourse} ishorizontal={ishorizontal}
                          />
                        : <CradBody
                          path={`/${path}`}
                          slug={`/${item.slug}`}
                          title={item.title}
                          lessons={item.lessons}
                          lessonList={list} type={iscourse}
                        />
                     }
            </div></div>);
      }
      return '';
    });
    return newList;
  },

  slugify: string =>
    string.toLowerCase().replace(/[^\w\s-]/g, '').replace(/[\s_-]+/g, '-').replace(/^-+|-+$/g, ''),

  copyTextToClipboard: (text) => {
    const textArea = document.createElement('textarea');
    textArea.style.position = 'fixed';
    textArea.style.top = 0;
    textArea.style.left = 0;
    textArea.style.width = '2em';
    textArea.style.height = '2em';
    textArea.style.padding = 0;
    textArea.style.border = 'none';
    textArea.style.outline = 'none';
    textArea.style.boxShadow = 'none';
    textArea.style.background = 'transparent';
    textArea.value = text;

    document.body.appendChild(textArea);
    textArea.select();

    document.body.removeChild(textArea);
  },

  isEmpty: (obj) => {
    // eslint-disable-next-line no-restricted-syntax
    for (const key in obj) {
      // eslint-disable-next-line no-prototype-builtins
      if (obj.hasOwnProperty(key)) {
        return false;
      }
    }
    return true;
  },
  getAppVersion: (element) => {
    $.ajax('./static/version.json').done((response) => {
      if (response) {
        const date = new Date(response.version.buildDate);
        const monthNames = [
          'January',
          'February',
          'March',
          'April',
          'May',
          'June',
          'July',
          'August',
          'September',
          'October',
          'November',
          'December'
        ];
        $(element).html(`v${response.version.version} (Built on ${date.getDate()} ${monthNames[date.getMonth()]} ${date.getFullYear()})`);
      }
    });
  },
  checkUserCourses: (userCourses, courseId) => userCourses.includes(courseId)
};

function CardHeader(props) {
  const path = `${props.path}${props.slug}`;
  console.log('helpers path ', path);
  return (

    <Link className="card-image" title={props.title} to={{ pathname: path }}>

      {props.featuredImage
  ? <IronImage placeholder={placeholder} src={props.item.featuredImage} alt={props.title} />
  : <div className="card-thumb">
    <span>{props.item.code}</span>
  </div>}


      <FreeorPremium type={props.type} premium="premium" />
    </Link>
  );
}


function FreeorPremium(props) {
  if (!props.type) { return null; }

  return (
    <span
      className={`free-or-premium tag is-${props.premium} center-flex`}
    >
      <FontAwesomeIcon icon="lock" />
      <span className="m-l-xs">Premium</span></span>
  );
}

function CradBody(props) {
  return (
    <div>
      <CardContent lessons={props.lessons} path={props.path} slug={props.slug} title={props.title} type={props.type} />
      <LessonsList lessons={props.lessons} path={props.path} slug={props.slug} lessonList={props.lessonList} type={props.type} />
      <CardFooter lessons={props.lessons} path={props.path} slug={props.slug} title={props.title} type={props.type} />
    </div>
  );
}


function HorizontalCard(props) {
  if (!props.ishorizontal) return null;

  return (
    <div className="horizontal-content">
      <div className="horizontal-content">
        <div className="card-content">
          <div className="card-date has-text-grey-light m-b-sm is-size-7">{props.date}</div>
          <h2 className="card-title is-2">
            <Link className="card-image" title={props.title} to={`${props.path}${props.slug}`}>
              <span className="ais-Highlight"><span className="ais-Highlight-nonHighlighted">{props.title}</span></span>
            </Link>
          </h2>
        </div>
        <div className="card-footer">
          <div className="is-hidden-touch"><a>JN</a></div>
        </div>
      </div>
    </div>
  );
}

function CardContent(props) {
  if (!props.type) return null;

  const count = Object.keys(props.lessons).length;
  return (
    <div className="card-content">
      <h2 className="card-title">
        <Link className="card-image" title={props.title} to={`${props.path}${props.slug}`}>
          {props.title}
        </Link>

      </h2>
      <p><span>{count} Lessons</span></p>
    </div>
  );
}

function LessonsList(props) {
  if (!props.type) return null;

  // if (!props.lessons) return null;

  const listItems = Object.keys(props.lessonList).slice(0, 4).map((key) => {
    const item = props.lessonList[key];
    return (<li key={key}>
      <Link to={`${props.path}${props.slug}/${item.slug}`} className="lesson-item" title={item.title}>
        <div className="video">
          <FontAwesomeIcon icon="play-circle" />
        </div>
        <h3 className="card-title"><span className="ais-Highlight"><span className="ais-Highlight-nonHighlighted">{item.title}</span></span></h3>
        <div className="card-actions"><span>{item.video_length}</span></div>
      </Link></li>);
  });


  return (
    <ul className="card-lesson-list">
      {listItems}

    </ul>
  );
}

function CardFooter(props) {
  if (!props.type) return null;

  const count = Object.keys(props.lessons).length - 4;


  return (
    <div className="card-footer">
      <p>{count} more lessons...</p>
      <Link className="button is-outlined is-info is-rounded" title="Start Course" to={`${props.path}${props.slug}`}>
      Start
                  Course<span className="m-l-xs"><FontAwesomeIcon icon="terminal" /></span>
      </Link>

    </div>
  );
}
