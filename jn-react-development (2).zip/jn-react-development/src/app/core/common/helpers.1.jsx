/* eslint-disable jsx-a11y/href-no-hash */
import React from 'react';
import $ from 'jquery';
import moment from 'moment';
import { Link } from 'react-router';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import IronImage from '../common/lib/ironimage/ironImage';
import { converter } from '../constants/constants';
import placeholder from '../../../../static/img/logo-big.jpg';
// CSS3 animation helper to cleanup classes after animationd ends
$.fn.extend({
  animateCss(animationName, callback) {
    const animationEnd = 'webkitAnimationEnd mozAnimationEnd MSAnimationEnd oanimationend animationend';
    $(this).addClass(`animated ${animationName}`).one(animationEnd, () => {
      $(this).removeClass(`animated ${animationName}`);
      if (callback) {
        callback();
      }
    });
  }
});

// String capitalization
String.prototype.capitalize = () => (this ? this.charAt(0).toUpperCase() + this.slice(1) : null);

// Common app methods
module.exports = {


  renderCards: (type, props, search) => {
    let newList = [];
    const path = type;
    let iscourse = true;
    let ishorizontal = false;
    let card = String;
    const list = [{
      id: 0,
      title: 'intro',
      something: 'blabla'
    },
    {
      id: 1,
      title: 'balbla',
      something: 'blabla'
    },
    {
      id: 2,
      title: 'balbla',
      something: 'blabla'
    },
    {
      id: 3,
      title: 'finish',
      something: 'blabla'
    }
    ];

    if (type === 'blog') {
      type = 'posts';
      card = 'is-post is-horizontal';
      iscourse = false;
      ishorizontal = true;
    } else {
      card = 'is-course';
      iscourse = true;
      ishorizontal = false;
    }

    newList = Object.keys(props[type]).map((key) => {
      let item = props[type][key];
      if (item.title.indexOf(search) !== -1) {
        item = props[type][key];
      }
      const date = (type === 'courses')
          ? item.startDate
          : item.date;

      console.log('item ', path);

      if (item && item.status && item.status !== 'inactive') {
        return (
          <li key={key} ref={`item-${key}`} className={`card ${type}-card`}>
            <Link to={`/${path}/${item.slug}`}>{item.featuredImage
              ? <div
                className="card-thumb card-image" style={{
                  backgroundImage: `url(${props.files[item.featuredImage].url})`
                }}
              />
              : <div className="card-thumb">
                <span>{item.code}</span>
              </div>}</Link>
            <div className="card-wrapper clearfix">
              <h3 className="card-title">
                <Link to={`/${path}/${item.slug}`}>{item.title}</Link>
              </h3>
              <div className="card-meta">
                <p>{(type === 'courses')
                  ? 'Starts '
                  : ''}
                  <span className="card-date">{item.startDate || item.date
                    ? moment(date).format('D/M/YYYY')
                    : 'anytime'}</span>
                  {(type === 'courses' && item.level)
                  ? <span>{props.levels[item.level].code}</span>
                  : ''}
                </p>
              </div>
              <div
                className="card-content" dangerouslySetInnerHTML={{
                  __html: converter.makeHtml(item.content1)
                }}
              />
              {(type === 'posts')
              ? <div className="card-actions">
                <button className="btn btn-xs btn-secondary float-right">
                  <Link to={`/${path}/${item.slug}`}>Read more</Link>
                </button>
              </div>
              : <div className="card-info">
                <span className="card-enrolled">
                  1.5K enrolled</span>
                {item.price
                  ? <span className="card-price">{item.price}€</span>
                  : ''}
              </div>}
            </div>
          </li>);
      }
      return '';
    });
    return newList;
  },

  slugify: string =>
    string.toLowerCase().replace(/[^\w\s-]/g, '').replace(/[\s_-]+/g, '-').replace(/^-+|-+$/g, ''),

  copyTextToClipboard: (text) => {
    const textArea = document.createElement('textarea');
    textArea.style.position = 'fixed';
    textArea.style.top = 0;
    textArea.style.left = 0;
    textArea.style.width = '2em';
    textArea.style.height = '2em';
    textArea.style.padding = 0;
    textArea.style.border = 'none';
    textArea.style.outline = 'none';
    textArea.style.boxShadow = 'none';
    textArea.style.background = 'transparent';
    textArea.value = text;

    document.body.appendChild(textArea);
    textArea.select();

    document.body.removeChild(textArea);
  },

  getAppVersion: (element) => {
    $.ajax('/static/version.json').done((response) => {
      if (response) {
        const date = new Date(response.version.buildDate);
        const monthNames = [
          'January',
          'February',
          'March',
          'April',
          'May',
          'June',
          'July',
          'August',
          'September',
          'October',
          'November',
          'December'
        ];
        $(element).html(`v${response.version.version} (Built on ${date.getDate()} ${monthNames[date.getMonth()]} ${date.getFullYear()})`);
      }
    });
  }
};

function CardHeader(props) {
  return (

    <Link className="card-image" title={props.title} to={`${props.path}${props.slug}`}>

      {props.featuredImage
  ? <IronImage placeholder={placeholder} src={props.files[props.item.featuredImage].url} alt={props.title} />
  : <div className="card-thumb">
    <span>{props.item.code}</span>
  </div>}


      <FreeorPremium type={props.type} premium="premium" />
    </Link>
  );
}


function FreeorPremium(props) {
  if (!props.type) { return null; }

  return (
    <span
      className={`free-or-premium tag is-${props.premium} center-flex`}
    >
      <FontAwesomeIcon icon="lock" />
      <span className="m-l-xs">Premium</span></span>
  );
}

function CradBody(props) {
  return (
    <div>
      <CardContent path={props.path} slug={props.slug} title={props.title} type={props.type} />
      <LessonsList lessonList={props.lessonList} type={props.type} />
      <CardFooter path={props.path} slug={props.slug} title={props.title} type={props.type} />
    </div>
  );
}


function HorizontalCard(props) {
  if (!props.ishorizontal) return null;

  return (
    <div className="horizontal-content">
      <div className="horizontal-content">
        <div className="card-content">
          <div className="card-date has-text-grey-light m-b-sm is-size-7">{props.date}</div>
          <h2 className="card-title is-2">
            <Link className="card-image" title={props.title} to={`${props.path}${props.slug}`}>
              <span className="ais-Highlight"><span className="ais-Highlight-nonHighlighted">{props.title}</span></span>
            </Link>
          </h2>
        </div>
        <div className="card-footer">
          <div className="is-hidden-touch"><a>JN</a></div>
        </div>
      </div>
    </div>
  );
}

function CardContent(props) {
  if (!props.type) return null;


  return (
    <div className="card-content">
      <h2 className="card-title">
        <Link className="card-image" title={props.title} to={`${props.path}${props.slug}`}>
          {props.title}
        </Link>

      </h2>
      <p><span>14 Lessons</span><span>1.42 hours</span></p>
    </div>
  );
}

function LessonsList(props) {
  if (!props.type) return null;

  const lessonList = props.lessonList;

  const listItems = lessonList.map(title =>
    <li key={title.id}>
      <a href="/" className="lesson-item" title={title.title}>
        <div className="video">
          <FontAwesomeIcon icon="play-circle" />
        </div>
        <h3 className="card-title"><span className="ais-Highlight"><span className="ais-Highlight-nonHighlighted">{title.title}</span></span></h3>
        <div className="card-actions"><span>5:12</span></div>
      </a></li>
);


  return (
    <ul className="card-lesson-list">
      {listItems}

    </ul>
  );
}

function CardFooter(props) {
  if (!props.type) return null;


  return (
    <div className="card-footer">
      <p>11 more lessons...</p>
      <Link className="button is-outlined is-info is-rounded" title="Start Course" to={`${props.path}${props.slug}`}>
      Start
                  Course<span className="m-l-xs"><FontAwesomeIcon icon="terminal" /></span>
      </Link>

    </div>
  );
}
