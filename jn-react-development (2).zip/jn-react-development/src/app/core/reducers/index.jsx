import { combineReducers } from 'redux';
import { routerReducer } from 'react-router-redux';
// import { firebaseStateReducer } from 'redux-react-firebase';
import { firebaseReducer } from 'react-redux-firebase';
import mainReducer from './mainReducer';

const rootReducer = combineReducers({
  mainReducer,
  firebase: firebaseReducer,
  routing: routerReducer
});

export default rootReducer;
