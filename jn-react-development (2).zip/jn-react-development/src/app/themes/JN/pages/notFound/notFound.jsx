import React, { Component } from 'react';
import { Link } from 'react-router';
import { connect } from 'react-redux';
import $ from 'jquery';
import { setLoading } from '../../../../core/actions/actions';
import notfount from '../../../../../../static/svg/404.svg';
import Icon from './../../../../core/common/lib/icon/icon';
import rocket from '../../../../../../static/svg/rocket.svg';
import earth from '../../../../../../static/svg/earth.svg';
import moon from '../../../../../../static/svg/moon.svg';
import astronaut from '../../../../../../static/svg/astronaut.svg';


class NotFound extends Component {

  componentDidMount() {
    this.props.setLoading(false);
    $('.js-main').removeClass().addClass('main js-main not-found-page');
  }

  render() {
    return (
      <section className="notFound page static-page bg-purple">
        <div className="stars">
          <div className="central-body">
            <Icon className="image-404" glyph={notfount} width="300px" />
            <Link to="/" >
              <div className="btn-go-home" >
              GO BACK HOME
              </div>
            </Link>
          </div>
          <div className="objects">
            <Icon className="object_rocket" glyph={rocket} width="40px" />
            <div className="earth-moon">
              <Icon className="object_earth" glyph={earth} width="100px" />
              <Icon className="object_moon" glyph={moon} width="80px" />
            </div>
            <div className="box_astronaut">
              <Icon className="object_astronaut" glyph={astronaut} width="140px" />
            </div>
          </div>
          <div className="glowing_stars">
            <div className="star" />
            <div className="star" />
            <div className="star" />
            <div className="star" />
            <div className="star" />
          </div>
        </div>
      </section>
    );
  }
}

const mapStateToProps = null;

const mapDispatchToProps = {
  setLoading
};

export default connect(mapStateToProps, mapDispatchToProps)(NotFound);
