import React from 'react';
import './shimmer.scss';

const iframeStyle = {
  position: 'absolute',
  top: '0',
  left: '0',
  width: '100%',
  height: '100%'
};
const divStyle = {
  padding: '56.25% 0 0 0',
  position: 'relative'
};
const VideoShimmer = () => (<div className="animate" style={divStyle}>
  <div
    style={iframeStyle}
  />
</div>);

export default VideoShimmer;
