/* eslint-disable jsx-a11y/anchor-has-content */
import React, { Component } from 'react';
import $ from 'jquery';
// import { firebase, helpers } from 'redux-react-firebase';
import { firebaseConnect, populate, getVal, isLoaded, isEmpty } from 'react-redux-firebase/lib';
import { connect } from 'react-redux';
import { compose } from 'redux';
// import find from 'lodash/find';
import { Link } from 'react-router';
import _ from 'lodash';
import { setLoading, fetchcourse, fetchlessons, setCoursesData } from '../../../../core/actions/actions';
import JnLessonList from '../../components/jnlessonlist/jnlessonlist';
import VideoPlayer from '../../components/videoplayer/VideoPlayer';
import Helpers from '../../../../core/common/helpers';
import AuthorShimmer from './AuthorSimmer';
import VideoShimmer from './VideoShimmer';
import LessonsShimmer from './LessonsShimmer';
import Breadcrumbs from './../../components/breadcrumbs/breadcrumbs';

// const { isEmpty } = Helpers;

const iframeStyle = {
  position: 'absolute',
  top: '0',
  left: '0',
  width: '100%',
  height: '100%'
};


/*
@connect((state, props) => ({
  course: getVal(state.firebase, 'courses'),
  levels: getVal(state.firebase, 'levels'),
  // lessons: dataToJS(state.firebase, 'lessons'),
  subjects: getVal(state.firebase, 'subjects'),
  users: getVal(state.firebase, 'users'),
  files: getVal(state.firebase, 'files'),
  userID: state.mainReducer.user
      ? state.mainReducer.user.uid
      : '',
    // featuredImage: state.course.featuredImage ? state.course.featuredImage : '',
  courseID: props.course
      ? props.course[Object.keys(props.course)[0]].code
      : '',
  userData: getVal(state.firebase, `users/${state.mainReducer.user
      ? state.mainReducer.user.uid
      : ''}`)
}))
  @firebaseConnect(props => ([
   // `courses#orderByChild=slug&equalTo=${props.params.slug}`,
        // '/todos#populate=owner:users', // equivalent string notation
      { path: '/courses', queryParams: ['orderByChild=slug', `equalTo=${props.params.slug}`] },
   // 'levels',
   // 'subjects',
    // 'lessons',
    // `subjects#orderByKey&equalTo=${props.course ? props.course[Object.keys(props.course)[0]].subjects : ''}`,
    'users',
   // 'files',
    // `files#orderByChild=featuredImage&equalTo=${props.featuredImage}`
    `users/${props.userID}`
  ])) */
const populates = [
  // { child: 'instructor', root: 'users', keyProp: 'key', childParam: 'info' } // replace owner with user object
  { child: 'lessons', root: 'lessons' }
];
/* @firebaseConnect(props => [
  // { path: '/courses/featuredImage', storeAs: 'img' },
  { type: 'once', path: '/courses', queryParams: ['orderByChild=slug', `equalTo=${props.params.slug}`] }
  // { path: '/courses' }
])
@connect(
  ({ firebase }) => ({
    course: firebase.ordered.courses
    // course: firebase.data.courses
  }),

) */


class course extends Component {
/*   constructor(props) {
    super(props);


        store.subscribe(() => {
          // When state will be updated(in our case, when items will be fetched),
          // we will update local component state and force component to rerender
          // with new data.

           this.setState({
            items: store.getState().items;
          });
        });
  } */
/*   componentWillMount() {
    if (isEmpty(this.props.courseData)) {
      this.props.fetchcourse('slug', this.props.params.slug);
    } else if (Object.values(this.props.courseData)[0].slug !== this.props.params.slug) {
      this.props.fetchcourse('slug', this.props.params.slug);
    }
    // console.log('component will mount .........', this.props.courseData);
  } */

  componentDidMount() {
    this.props.setLoading(false);
    // this.props.fetchcourses('slug', this.props.slug);

    $('.js-main').removeClass().addClass('main js-main course-page');
   /*  console.log('pppp ', this.props.courseData)
    this.props.setCoursesData(this.props.courseData[0]); */
  }

  render() {
   // console.log('props c', this.props);
    let video = <VideoShimmer />; // <div className="loader-small" />;
    let list = <LessonsShimmer />; // <div className="loader-small" />;
    let lessons;
    let currentcourse;
    let author = <AuthorShimmer />;
    let courseObj;
   // let userD;
    if (!isEmpty(this.props.courseData)) {
      courseObj = this.props.courseData[0].value;
      lessons = courseObj.lessons;
     // userD = this.props.userData ? this.props.userData : '';
      console.log('course ', courseObj);

      const teaser = courseObj.teaser_video;
      // eslint-disable-next-line arrow-body-style
      const lessonVid = _.find(lessons, (s) => {
        return s.slug === this.props.params.lessonslug;
      });
      const videoId = this.props.params.lessonslug ? lessonVid.video_id : teaser;
      currentcourse = this.props.params.lessonslug ? lessonVid.position : 0;
     // console.log('video ', teaser);
      video = (<VideoPlayer id={videoId} style={iframeStyle} />);
    }
    if (isLoaded(this.props.courseData) && !isEmpty(this.props.courseData) && isLoaded(lessons) && !isEmpty(lessons)) {
     // list = (<ReactLessonList userData={this.props.userData.info} course={this.props.course} lessons={lessons} position={currentcourse} />);
     // console.log('courses props ', Helpers.checkUserCourses(Object.keys(this.props.userData.info.courses), Object.keys(this.props.courseData)[0]));
      list = <JnLessonList {...this.props} lessons={lessons} position={currentcourse} isBought={false} />;
      author = (<TitleCourse course={courseObj} />);

      // console.log('less ', t.video_id);
    }

    return (
      <section className="page course">
        <main id="scotchy-main">
          <div className="course-top-right-background" />
          <article className="article is-course  is-">
            <div className="article-background is-left" />
            <div className="article-background is-right" />
            <header className="article-header" />
            <div className="section content">
              <div className="container m-b-0 ">
                <div className="columns is-gapless">
                  <div className="column is-narrow is-left">
                    <div className="article-inner" />
                  </div>
                  <div className="column is-middle">
                    <div className="article-inner">
                      <div className="article-header is-course">
                        <div className="video-container" >
                          {video}
                        </div>
                        {author}
                      </div>
                    </div>
                  </div>
                  <div className="column is-narrow is-right"> <div className="article-inner">
                    {list}
                  </div> </div>
                </div>
              </div>
            </div>

          </article>
        </main>
      </section>

    );
  }
}

function TitleCourse(props) {
  const courseT = props.course;
  const instructor = Object.values(courseT.instructor)[0];
  // const instructorImg = `url(${instructor.avatar}`;
  return (
    <div className="article-title m-b-md">
      <h1 className="title is-2 m-t-0">
        {courseT.title}
      </h1>
      <div className="article-byline">
        <div className="jn-line">
          <div className="author">
            <div
              // to="../../@worldclassdev/index.html"
              className="img"
              title={instructor.avatarTitle}
              style={{
                backgroundImage:
                  `url(${instructor.avatar}`
              }}
            />
            <div title={instructor.displayName}>
              {instructor.displayName}
            </div>
            <a
              className="m-l-xs"
              href="https://twitter.com/worldclassdev"
              title="Follow @worldclassdev on Twitter"
            >
              (@worldclassdev)
              </a>
          </div>

        </div>
      </div>
    </div>
  );
}


const mapDispatchToProps = {
  setCoursesData,
  setLoading
};
const mapStateToProps = ({
  mainReducer: {
    isDesktop,
    userData
  }
}) => ({ isDesktop, userData });

const fire = firebaseConnect(props => [
  // { path: '/courses/featuredImage', storeAs: 'img' },
  { type: 'once', path: '/courses', queryParams: ['orderByChild=slug', `equalTo=${props.params.slug}`] }
  // { path: '/courses' }
]);

const con = connect(state => ({
  courseData: state.firebase.ordered.courses,
  isDesktop: state.mainReducer.isDesktop,
  userData: state.mainReducer.userData,
  breadcrumbs: state.mainReducer.breadcrumbs

  // profile: state.firebase.profile // load profile
}), mapDispatchToProps);

export default compose(con, fire)(course);
