import React from 'react';
import './shimmer.scss';

const LessonsShimmer = () => (<div className="jn-list lesson-list">

  <div className="lesson is-giant center-flex animate" >
    <br />
    <br />
    <br />
    <br />
    <br />
    <br />
  </div>

  <div className="jn-list-header lesson-list-header animate" />
  <div className="jn-list-item lesson animate">
    <div>
      <br />
      <br />
      <br />
      <br />
      <br />
      <span className="text animate" />
    </div>
    <div className="lesson-actions" /></div>;

</div>);

export default LessonsShimmer;
