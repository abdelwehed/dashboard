import React from 'react';
import './shimmer.scss';

const AuthorShimmer = () => (<div className="article-title m-b-md">
  <div className="comment br animate w80" />
  <div className="article-byline">
    <div className="jn-line">
      <div className="author">
        <div className="profilePic animate din" />
        <div className="comment br animate w80" />
      </div>

    </div>
  </div>
</div>);

export default AuthorShimmer;
