import React, { Component } from 'react';
import { connect } from 'react-redux';
import { compose } from 'redux';
// import { firebase, helpers } from 'redux-react-firebase';
import { firebaseConnect, populate, isLoaded, isEmpty } from 'react-redux-firebase';
import $ from 'jquery';
import { Link } from 'react-router';
import VideoPlayer from '../../components/videoplayer/VideoPlayer';
import Helpers from '../../../../core/common/helpers';
import { setLoading } from '../../../../core/actions/actions';
import Icon from '../../../../core/common/lib/icon/icon';
import World from '../../../../../../static/svg/world.svg';
import Logo from '../../../../../../static/svg/logo-01.svg';

// const { isLoaded, isEmpty, dataToJS } = helpers;
const divStyle = {
  padding: '56.25% 0 0 0',
  position: 'relative'
};
const iframeStyle = {
  position: 'absolute',
  top: '0',
  left: '0',
  width: '100%',
  height: '100%'
};
const config = {
  delay: 9000,
  startwidth: 1170,
  startheight: 500,
  hideThumbs: 10,
  fullWidth: 'on',
  forceFullWidth: 'on'
};
const populates = [
  // { child: 'instructor', root: 'users', keyProp: 'key', childParam: 'info' } // replace owner with user object
  { child: 'lessons', root: 'lessons' }
];
/*
@firebaseConnect(['files', 'posts', 'lessons', {
  path: 'courses',
  queryParams: ['limitToLast=10']
}, 'levels'])
@connect(state => ({
  files: getVal(state.firebase, 'files'),
  lessons: getVal(state.firebase, 'lessons'),
  courses: getVal(state.firebase, 'courses'),
  posts: getVal(state.firebase, 'posts'),
  levels: getVal(state.firebase, 'levels')
})) */
/* @firebaseConnect([
  {
    path: '/courses'
  },
  {
    path: '/posts'
  }
])
@connect(
  ({ firebase }) => ({
    courses: firebase.data.courses,
    posts: firebase.data.posts
  }),


) */
class Home extends Component {

  componentDidMount() {
    this.props.setLoading(false); // Move this to API callback when implemented (if ever)
    $('.js-main').removeClass().addClass('main js-main home-page has-hero');
    $('.hero .world-map').show().animateCss('slideInUp', () => {
      $('.hero .hero-content').show().animateCss('fadeInUp', () => {
        $('.hero .elevator-pitch').show().animateCss('fadeInUp');
        $('.hero .welcome-video').show().animateCss('fadeInUp');
        $('.hero .circle').show().animateCss('fadeInUp');
      });
    });
  }
  render() {
/*     let coursesList = <div className="loader-small" />;
    let postsList = <div className="loader-small" />;
    console.log('home props ', this.props);
    if (isLoaded(this.props.courses) && !isEmpty(this.props.courses)) {
      coursesList = (<div className="container">
        <div className="search-section search-courses">
          <div className="columns is-variable is-1 is-multiline">
            {Helpers.renderCards('courses', this.props)}
          </div>
        </div>
      </div>);
    }

    if (isLoaded(this.props.posts) && !isEmpty(this.props.posts) && isLoaded(this.props.files) && !isEmpty(this.props.files)) {
      postsList = <div className="blog-grid-container">{Helpers.renderCards('blog', this.props)}</div>;
    } */

    return (
      <section className="home page">
        <div className="hero">
          <Icon glyph={World} className="world-map" />
          <div className="hero-content">
            <Icon glyph={Logo} className="logo" />
            <div className="slogan">
              <div className="word word1">Open</div>
              <div className="word word2">Realtime</div>
              <div className="word word3">Education</div>
            </div>
          </div>
          <div className="elevator-pitch">
            <p>Junior Network is an international learning platform. You can study anytime, anywhere and network with your classmates around the world! You can also earn money by uploading your courses...</p>
          </div>
          <div className="welcome-video">
            <div className="card is-jn is-image ">
              <div className="card-image" >
                <VideoPlayer id="296005189?muted=1&autoplay=1&loop=1&color=ee2d27&title=0&byline=0&portrait=0" style={iframeStyle} />
              </div>
            </div>
          </div>
        </div>
        {/* <div className="cards courses">
          <h2 className="cards-heading">Latest courses</h2>
          {coursesList.type === 'div' ? coursesList :
          <Link to="/upload">
            <button className="btn btn-primary">Upload your first course</button>
          </Link>}
        </div>
        <div className="cards posts">
          <h2 className="cards-heading">Latest stories</h2>
          {postsList.type === 'div' ? postsList :
          <Link to="/admin">
            <button className="btn btn-primary">Write your first post</button>
          </Link>}
        </div> */}
      </section>
    );
  }
}

const mapDispatchToProps = {
  setLoading
};

const mapStateToProps = ({
  mainReducer: {
    isDesktop
  }
}) => ({ isDesktop });

/* const enhance = compose(
  firebaseConnect(() => [
    {
      path: '/courses',
      populates
    },
    {
      path: '/posts',
      populates
    }
  ]),
  connect(
    ({ firebase }) => ({
      courses: populate(firebase, 'courses', populates),
      posts: populate(firebase, 'posts', populates)
    }),
    mapDispatchToProps,

  )

); */

export default connect(mapStateToProps, mapDispatchToProps)(Home);
// export default enhance(Home);
