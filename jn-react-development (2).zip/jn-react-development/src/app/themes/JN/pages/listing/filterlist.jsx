import React, { Component } from 'react';
import { connectRefinementList } from 'react-instantsearch-dom';

class FilterList extends React.Component {

  constructor(props) {
    super(props);
    this.toggleItem = this.toggleItem.bind(this);
  }

  toggleItem(item) {
    this.refs[item].classList.toggle('checkbox-filter__item_is-active');
  }
  render() {
    return (
      <div className="checkbox-filter__list">

        {this.props.items.map(item => (
          <div
            key={item.label} ref={item.label} className="checkbox-filter__item"
          >
            <label className="checkbox-filter__label_phone">{item.count}</label>
            <label className="checkbox-filter__label" htmlFor={item.label}>{item.label}</label>
            <div className="checkbox-filter__input checkbox-input checkbox-input_toggle input_theme_light">
              <input
                className="checkbox-input__source" checked={item.getIsRefined} id={item.label} type="checkbox" onChange={(event) => {
                  // event.preventDefault(); this line prevent the checkbox from getting checked
                  this.props.refine(item.value);
                  this.toggleItem(item.label);
                }} name="checkbox-filter-toggle"
              />
              <label className="checkbox-input__label" htmlFor={item.label} />
            </div>
          </div>
        ))}
      </div>
    );
  }


}

export default connectRefinementList(FilterList);
