import React, { Component } from 'react';
import $ from 'jquery';
import { connect } from 'react-redux';
// import { firebase, helpers } from 'redux-react-firebase';
import { firebaseConnect, getVal, isLoaded, isEmpty } from 'react-redux-firebase';
import algoliasearch from 'algoliasearch/lite';
import { InstantSearch, SearchBox, Hits } from 'react-instantsearch-dom';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import Helpers from '../../../../core/common/helpers';
import { setLoading } from '../../../../core/actions/actions';


// const { isLoaded, isEmpty, dataToJS } = helpers;
const searchStyle = {
  width: '100%'
};
const searchClient = algoliasearch(
  '97MIO9N5DI',
  'bdf26407a9fe98fac16e38bbdf57b013'
);

@firebaseConnect(() => ([
  'courses',
  'lessons',
  'subjects',
  'modules',
  'activities',
  'posts',
  'levels',
  'files'
]))
@connect(state => ({
  courses: getVal(state.firebase, 'courses'),
  lessons: getVal(state.firebase, 'lessons'),
  subjects: getVal(state.firebase, 'subjects'),
  modules: getVal(state.firebase, 'modules'),
  activities: getVal(state.firebase, 'activities'),
  posts: getVal(state.firebase, 'posts'),
  levels: getVal(state.firebase, 'levels'),
  files: getVal(state.firebase, 'files')
}))


class Listing extends Component {

  constructor() {
    super();
    this.updateSearch = this.updateSearch.bind(this);
    this.state = {
      search: ''
    };
  }

  componentDidMount() {
    this.props.setLoading(false);
    $('.js-main').removeClass().addClass('main js-main listing-page');
  }

  updateSearch(event) {
    this.setState({ search: event.target.value.substr(0, 20) });
  }

  render() {
    let type = this.props.location.pathname.slice(1);
    let items = null;
    const path = type;
    let count = 0;

    if (path === 'blog') {
      type = 'posts';
    }
    if (isLoaded(this.props[type]) && !isEmpty(this.props[type]) && isLoaded(this.props.files) && isLoaded(this.props.lessons)) {
      const cards = Helpers.renderCards(path, this.props, this.state.search);
      items = (<div className="container">
        <div className="search-section search-courses">
          <div className="columns is-variable is-1 is-multiline">
            {cards}
          </div>
        </div>
      </div>);
      count = Object.keys(this.props[type]).length;
    } else {
      items = <div className="loader-small" />;
    }

    return (
      <div>
        <section className="section search-box is- ">
          <div className="icon">
            <FontAwesomeIcon icon="play-circle" />
          </div>
          <div className="container">
            <div style={searchStyle}>
              <div className="search-header">
                <h2 className="title search-title">{type}<small className="is-hidden-touch">Multi-lesson video tutorials</small></h2>
                <div className="is-hidden-touch">
                  <div className="ais-Stats"><span className="ais-Stats-text">{count} results found</span></div>
                </div>
              </div>
              <div className="ais-SearchBox">
                <form noValidate onSubmit={this.handler} className="ais-SearchBox-form" action="" role="search">
                  <input type="search" placeholder="Find cool stuff..." autoComplete="off" autoCorrect="off" autoCapitalize="off" spellCheck={false} required maxLength="512" value={this.state.search} onChange={this.updateSearch} className="ais-SearchBox-input" />
                </form>

              </div>

            </div>
          </div>
        </section>
        <section className="page listing-page">
          <div className="cards">
            <h1 className="cards-heading">{path}</h1>
            {items}
          </div>
        </section>
      </div>
    );
  }
}

const mapDispatchToProps = {
  setLoading
};

const mapStateToProps = ({
  mainReducer: {
    isDesktop
  }
}) => ({ isDesktop });

export default connect(mapStateToProps, mapDispatchToProps)(Listing);
