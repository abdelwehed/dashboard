/* eslint-disable react/jsx-indent */
/* eslint-disable jsx-a11y/href-no-hash */
import React, { Component } from 'react';
import $ from 'jquery';
import { connect } from 'react-redux';
// import { firebase, helpers } from 'redux-react-firebase';
import { firebaseConnect, getVal, isLoaded, isEmpty } from 'react-redux-firebase';
import algoliasearch from 'algoliasearch/lite';
import { connectSearchBox, InstantSearch, Stats, connectInfiniteHits, Configure, connectRefinementList } from 'react-instantsearch-dom';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import groupBy from 'lodash/groupBy';
import Helpers from '../../../../core/common/helpers';
import { setLoading } from '../../../../core/actions/actions';
import FilterList from './filterlist';


// const { isLoaded, isEmpty, dataToJS } = helpers;
const searchStyle = {
  width: '100%'
};
const searchClient = algoliasearch(
  '97MIO9N5DI',
  'bdf26407a9fe98fac16e38bbdf57b013'
);
const populates = [
  // { child: 'instructor', root: 'users', keyProp: 'key', childParam: 'info' } // replace owner with user object
  { child: 'lessons', root: 'lessons' }
];
/* @firebaseConnect(() => ([
  'courses',
  'lessons',
  'subjects',
  'modules',
  'activities',
  'posts',
  'levels',
  'files',
  'category'
]))
@connect(state => ({
  courses: getVal(state.firebase, 'courses'),
  lessons: getVal(state.firebase, 'lessons'),
  subjects: getVal(state.firebase, 'subjects'),
  modules: getVal(state.firebase, 'modules'),
  activities: getVal(state.firebase, 'activities'),
  posts: getVal(state.firebase, 'posts'),
  levels: getVal(state.firebase, 'levels'),
  files: getVal(state.firebase, 'files'),
  category: state.firebase.data.category
}))
 */

class Listing extends Component {

  constructor() {
    super();
    this.handleCheckChieldElement = this.handleCheckChieldElement.bind(this);
  }

  componentDidMount() {
    this.props.setLoading(false);
   // console.log('listings ', this.props);
    $('.js-main').removeClass().addClass('main js-main listing-page');
  }

  handleCheckChieldElement(event) {
    const subcategories = this.state.subcategories;
    subcategories.forEach((subcategory) => {
      if (subcategory.value === event.target.value) {
        subcategory.isRefined = event.target.checked;
      }
    });
  }

  render() {
    let type = this.props.location.pathname.slice(1);
    const path = type;


    if (path === 'blog') {
      type = 'posts';
    }

    return (
      <div>
        <InstantSearch
          indexName="courses"
          searchClient={searchClient}
        >

          <CustomSearchBox />
          <Configure
            hitsPerPage={10}
            maxValuesPerFacet={4}
          />
          <CustomInfiniteHits />
        </InstantSearch>
      </div>
    );
  }
}

const SearchBox = ({ currentRefinement, refine }) => (
  <section className="section search-box is- ">
    <div className="icon">
      <FontAwesomeIcon icon="play-circle" />
    </div>
    <div className="container">
      <div style={searchStyle}>
        <div className="search-header">
          <h2 className="title search-title">Courses<small className="is-hidden-touch">Multi-lesson video courses</small></h2>
          <div className="is-hidden-touch">
            <div className="ais-Stats"><Stats /></div>
          </div>
        </div>
        <form noValidate action="" role="search">
          <input
            type="search"
            value={currentRefinement}
            placeholder="Find cool stuff..." autoComplete="off" autoCorrect="off" autoCapitalize="on" spellCheck={false} required maxLength="512" className="ais-SearchBox-input"
            onChange={event => refine(event.currentTarget.value)}
          />
        </form>


      </div>
    </div>
  </section>
);
const InfiniteHits = ({ hits, hasMore, refine }) => {
  let items;
  if (hits.length) {
    // eslint-disable-next-line no-shadow
    const json = hits.reduce((json, value, key) => { json[value.objectID] = value; return json; }, {});
    const courses = { courses: json };
    const cards = Helpers.renderCards('courses', courses, '');
    items = (<div className="container">
      <div className="search-section search-courses">
        <div className="columns is-variable is-1 is-multiline">
          {cards}
        </div>
      </div>
    </div>);
  } else {
    items = <div className="loader-small" />;
  }
  return (
    <section className="page listing-page">
      <div className="checkbox-filter">
        <div className="checkbox-filter__container">
          <FilterList attribute="subcategory" />
        </div>
      </div>
      {/*           <div className="menu-list tag-filter-list is-horizontal">
          <span style={color}>Category : </span>
            <div className="sort-by select is-rounded">
            <CustomRefinementList attribute="category" />

            </div>
            <span style={color}> | </span>
            <span style={color}>SubCategory : </span>

            <div className="sort-by select is-rounded">
            <CustomRefinementList2 attribute="subcategory" />

            </div>
          </div> */}
      <div className="cards">
        <h1 className="cards-heading">courses</h1>
        {items}
      </div>
      <div className="cards-heading">
        <button className="button is-fullwidth is-showmore is-inverted" disabled={!hasMore} onClick={refine}>
          Show more
    </button>
      </div>
    </section>
  );
};


const test = (e) => {
  /*   const Nclass = $(e.target).attr('class');
    console.log('click ', $(e.target).attr('class'));
    $(`.${Nclass}`).removeClass().addClass(`checkbox-filter__item_is-active ${Nclass}`); */
  const filterItems = document.querySelectorAll('.checkbox-filter__item');


  filterItems.forEach(filter => filter.addEventListener('change', () => filter.classList.toggle('checkbox-filter__item_is-active')));
};


const SubCatRefinementList = ({
  items,
  isFromSearch,
  refine,
  searchForItems,
  createURL
}) => (
    <div className="checkbox-filter__list">

      {items.map(item => (
        <div
          key={item.label} className="checkbox-filter__item" onClick={(event) => {
            // event.preventDefault(); this line prevent the checkbox from getting checked
            test(event);
          }}
        >
          <label className="checkbox-filter__label_phone">{item.count}</label>
          <label className="checkbox-filter__label" htmlFor={item.label}>{item.label}</label>
          <div className="checkbox-filter__input checkbox-input checkbox-input_toggle input_theme_light">
            <input
              className="checkbox-input__source" checked={item.getIsRefined} id={item.label} type="checkbox" onChange={(event) => {
                // event.preventDefault(); this line prevent the checkbox from getting checked
                refine(item.value);
              }} name="checkbox-filter-toggle"
            />
            <label className="checkbox-input__label" htmlFor={item.label} />
          </div>
        </div>
      ))}
    </div>
  );


const SubCategoryRefinementList = connectRefinementList(SubCatRefinementList);
const CustomInfiniteHits = connectInfiniteHits(InfiniteHits);

const CustomSearchBox = connectSearchBox(SearchBox);


const mapDispatchToProps = {
  setLoading
};

const mapStateToProps = ({
  mainReducer: {
    isDesktop,
    courseData
  }
}) => ({ isDesktop, courseData });

export default connect(mapStateToProps, mapDispatchToProps)(Listing);
