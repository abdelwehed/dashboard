/* eslint-disable class-methods-use-this */
/* eslint-disable no-undef */
import React, { Component } from 'react';
import $ from 'jquery';
import { connect } from 'react-redux';
import firebase from 'firebase';
import { history } from '../../../../store';
import { setNotification, setLoading } from '../../../../core/actions/actions';
import './signin.scss';
import Icon from './../../../../core/common/lib/icon/icon';
import rocket from '../../../../../../static/svg/rocket.svg';
import earth from '../../../../../../static/svg/earth.svg';
import moon from '../../../../../../static/svg/moon.svg';
import astronaut from '../../../../../../static/svg/astronaut.svg';

class SignIn extends Component {
  constructor(props) {
    super(props);
    this.handleSignup = this.handleSignup.bind(this);
    this.handleSignin = this.handleSignin.bind(this);
    this.resetPwd = this.resetPwd.bind(this);
    this.switchToRegister = this.switchToRegister.bind(this);
    this.handleForgetPsw = this.handleForgetPsw.bind(this);
  }
  componentDidMount() {
    this.props.setLoading(false);
    $('.js-main').removeClass().addClass('main js-main login-page');
  }
  handleSignup(e) {
    e.preventDefault();

    const { password, password2, firstname, lastname } = this.refs;

    if (password.value === password2.value) {
      $('#js-btn-signup').hide();
      $('.js-signup-loader').show();

      const email = String(this.refs.email.value);

      firebase.auth().createUserWithEmailAndPassword(email, password.value).then((user) => {
        this.saveUser(firebase.auth().currentUser, firstname.value, lastname.value, email);
      }).catch((error) => {
        $('#js-btn-signup').show();
        $('.js-signup-loader').hide();
        this.props.setNotification({ message: String(error), type: 'error' });
      });
    } else {
      this.props.setNotification({ message: PASSWORD_MATCH_ERROR, type: 'error' });
    }
  }

  saveUser(user, firstname, lastname, email) {
    return firebase.database().ref(`users/${user.uid}/info`).set({
      firstName: firstname,
      lastName1: lastname,
      email,
      displayName: `${firstname} ${lastname}`
    }).then(() => {
      this.sendVerificationMail();
      $('#js-btn-signup').show();
      $('.js-signup-loader').hide();
     // $('.js-overlay').click();
    })
        .catch((error) => {
          $('#js-btn-signup').show();
          $('.js-signup-loader').hide();
          this.props.setNotification({ message: String(error), type: 'error' });
        });
  }

      // eslint-disable-next-line class-methods-use-this
  sendVerificationMail() {
    firebase.auth().currentUser.sendEmailVerification()
        .then(() => {
          // Verification email sent.
          this.props.setNotification({ message: USER_CONFIRM_EMAIL, type: 'success' });
        })
        .catch((error) => {
          // Error occurred. Inspect error.code.
          this.props.setNotification({ message: String(error), type: 'error' });
        });
  }


  switchToRegister(e) {
   // Switch to Register

    $('#register, #form').toggleClass('toggle');
  }
  handleForgetPsw(e) {
    // Switch to Forgot Password

    $('#forgot').toggleClass('toggle');
  }
  resetPwd(e) {
         // e.preventDefault();
    $('#js-btn-reset').hide();
    $('.js-reset-loader').show();
    // $('.js-btn-reset').hide();
    firebase.auth().sendPasswordResetEmail(this.refs.email.value).then(() => {
      // Email sent.
      this.props.setNotification({ message: 'Reset mail has been sent', type: 'info' });
    }).catch((error) => {
      // An error happened.
      $('.js-btn-reset').show();
      $('.js-reset-loader').hide();

      this.props.setNotification({ message: String(error), type: 'error' });
    });
  }

  handleSignin(e) {
    e.preventDefault();
    $('#js-btn-signin').hide();
    $('.js-signin-loader').show();
    console.log('refsss ', this.props);
    const email = String(this.refs.email.value);
    const { password } = this.refs;

    firebase.auth().signInWithEmailAndPassword(email, password.value).then(() => {
      $('#js-btn-signin').show();
      $('.js-signin-loader').hide();
     // $('.js-overlay').click();
      history.goBack();
    }).catch((error) => {
      $('#js-btn-signin').show();
      $('.js-signin-loader').hide();
      const errorCode = error.code;
      if (errorCode === 'auth/wrong-password') {
       // $('.js-btn-reset').show();
        this.props.setNotification({ message: 'Wrong email or password', type: 'error' });
      } else {
        this.props.setNotification({ message: String(error), type: 'error' });
      }
    });
  }
  render() {
    return (
      <section className="login-page page static-page bg-purple">
        <div className="stars">
          <div className="central-body">

            <div id="formContainer">
              <div id="form">
                {/* <div id="formLeft" className="f">
                  <img src="./static/img/logo.png" alt="Avatar" />
                  <h2>Alien Dimension</h2>
                </div> */}
                <div id="formRight">
                  <form autoComplete="off" onSubmit={this.resetPwd} id="forgot" className="contentArea otherForm">
                    <div className="formHead">
                      <h1>Forgot Password?</h1>
                      <p>Looks like you forgot your password</p>
                    </div>
                    <label className="formDiv">
                      <input type="email" placeholder=" " required />
                      <p>Type your Email</p>
                      <span className="border" />
                    </label>
                    <div className="formDiv">
                      <input type="submit" id="js-btn-reset" defaultValue="Send" />
                      <div className="loader-small js-reset-loader" />
                    </div>
                    <footer>
                      <p className="forgotBtn" onClick={this.handleForgetPsw} >Back to Login</p>
                    </footer>
                  </form>
                  <form autoComplete="off" id="register" onSubmit={this.handleSignup} className="contentArea otherForm">
                    <div className="formHead">
                      <h1>BECOME AN ALIEN</h1>
                      <p>Register to gain full access</p>
                    </div>
                    <label className="formDiv">
                      <input type="text" placeholder=" " />
                      <p>Username</p>
                      <span className="border" />
                    </label>
                    <label className="formDiv">
                      <input type="email" placeholder=" " />
                      <p>Email</p>
                      <span className="border" />
                    </label>
                    <label className="formDiv">
                      <input type="password" placeholder=" " />
                      <p>Password</p>
                      <span className="border" />
                    </label>
                    <div className="formDiv">
                      <input type="submit" id="js-btn-signup" defaultValue="Register" />
                      <div className="loader-small js-signup-loader" />
                    </div>
                    <footer>
                      <p className="registerBtn" onClick={this.switchToRegister} >Back to login</p>
                    </footer>
                  </form>
                  <form autoComplete="off" className="contentArea" id="login" onSubmit={this.handleSignin}>
                    <div className="formHead">
                      <h1>WELCOME BACK</h1>
                      <p>Login to continue</p>
                    </div>
                    <label className="formDiv">
                      <input type="email" ref="email" placeholder=" " required />
                      <p>Email</p>
                      <span className="border" />
                    </label>
                    <label className="formDiv">
                      <input type="password" ref="password" placeholder=" " required />
                      <p>Password</p>
                      <span className="border" />
                    </label>
                    <div className="formDiv">
                      <input type="submit" id="js-btn-signin" defaultValue="Login" />
                      <div className="loader-small js-signin-loader" />

                    </div>
                    <footer>
                      <p className="forgotBtn" onClick={this.handleForgetPsw} >Forgot password</p>
                      <p className="registerBtn" onClick={this.switchToRegister} >Need an Account?</p>
                    </footer>
                  </form>
                </div>
              </div>
            </div>
          </div>
          <div className="objects">
            <Icon className="object_rocket" glyph={rocket} width="40px" />
            <div className="earth-moon">
              <Icon className="object_earth" glyph={earth} width="100px" />
              <Icon className="object_moon" glyph={moon} width="80px" />
            </div>
            <div className="box_astronaut">
              <Icon className="object_astronaut" glyph={astronaut} width="140px" />
            </div>
          </div>
          <div className="glowing_stars">
            <div className="star" />
            <div className="star" />
            <div className="star" />
            <div className="star" />
            <div className="star" />
          </div>
        </div>
      </section>
    );
  }
}

const mapDispatchToProps = {
  setLoading,
  setNotification
};

const mapStateToProps = ({
    mainReducer: {
      isDesktop
    }
  }) => ({ isDesktop });

export default connect(mapStateToProps, mapDispatchToProps)(SignIn);
