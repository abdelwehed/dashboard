import $ from 'jquery';
import React, { Component } from 'react';
import { connect } from 'react-redux';
// mport { firebase, helpers } from 'redux-react-firebase';
import { firebaseConnect, isEmpty, isLoaded } from 'react-redux-firebase';
import { setLoading, setNotification, setUser, setUserData } from '../../../../core/actions/actions';
import * as CONSTANTS from '../../../../core/constants/constants';

// const { isEmpty, isLoaded } = helpers;

@firebaseConnect()
class Settings extends Component {

  constructor(props) {
    super(props);

    this.state = {
      info: {},
      picture: null,
      pictureUrl: null
    };

    this.handleChange = this.handleChange.bind(this);
  }

  componentWillMount() {
    this.props.setLoading(false);
    $('.js-main').removeClass().addClass('main js-main account-settings-page');

    if (isEmpty(this.state.info) && isLoaded(this.props.userData)) {
      this.setState({ info: this.props.userData.info });
    }
    $('.js-password-loader').hide();
    $('.js-info-loader').hide();
  }

  componentWillReceiveProps(newProps) {
    if (newProps.userData && (newProps.userData !== this.props.userData) && isEmpty(this.state.info)) {
      this.setState({ info: newProps.userData.info });
    }
  }

  updatePassword() {
    if (this.refs.password.value === this.refs.password2.value) {
      if (this.refs.password.value.length >= 6) {
        if (this.props.user.email !== CONSTANTS.DEMO_EMAIL) {
          $('.is-info').hide();
          $('.js-password-loader').show();

          this.props.user.updatePassword(this.refs.password.value).then(() => {
            $('.is-info').show();
            $('.js-password-loader').hide();
            this.props.setNotification({ message: CONSTANTS.PASSWORD_CHANGED, type: 'success' });
          }, (error) => {
            $('.is-info').show();
            $('.js-password-loader').hide();
            this.props.setNotification({ message: String(error), type: 'error' });
          });
        }
      } else {
        this.props.setNotification({ message: CONSTANTS.PASSWORD_MIN_LENGTH_ERROR, type: 'error' });
      }
    } else {
      this.props.setNotification({ message: CONSTANTS.PASSWORD_MATCH_ERROR, type: 'error' });
    }
  }

  updateUserInfo() {
    if (this.props.user.email !== CONSTANTS.DEMO_EMAIL && this.state.picture === null) {
      if (this.state.info.displayName === '' || this.state.info.firstName === '' || this.state.info.lastName1 === '') {
        this.props.setNotification({ message: CONSTANTS.USER_INFO_EMPTY, type: 'error' });
        return;
      }
      console.log('photo ', this.state.picture);
      $('.is-info').hide();
      $('.js-info-loader').show();

      this.props.firebase.set(`users/${this.props.user.uid}/info`, this.state.info).then(() => {
        $('.is-info').show();
        $('.js-info-loader').hide();
        this.props.setNotification({ message: CONSTANTS.USER_INFO_CHANGED, type: 'success' });

        if (this.props.user.email !== this.state.info.email) {
          this.props.user.updateEmail(this.state.info.email).then(() => {
            this.props.user.sendEmailVerification();
            this.props.firebase.logout();
            this.props.setUser(null);
          }, (error) => {
            $('.js-btn-email').show();
            $('.js-email-loader').hide();
            this.props.setNotification({ message: String(error), type: 'error' });
          });
        }
      }, (error) => {
        $('.is-info').show();
        $('.js-info-loader').hide();
        this.props.setNotification({ message: String(error), type: 'error' });
      });
    } else {
      if (this.state.info.displayName === '' || this.state.info.firstName === '' || this.state.info.lastName1 === '') {
        this.props.setNotification({ message: CONSTANTS.USER_INFO_EMPTY, type: 'error' });
        return;
      }
      $('.is-info').hide();
      $('.js-info-loader').show();
      this.props.firebase.storage().ref(`useravatar/${this.props.user.uid}`).put(this.state.picture).then((snapshot) => {
        snapshot.ref.getDownloadURL().then((downloadURL) => {
          console.log('File available at', downloadURL);
          const newInfo = Object.assign({}, this.state.info, {
            profilePicture: downloadURL
          });
          this.setState({ info: newInfo });
          this.props.firebase.set(`users/${this.props.user.uid}/info`, this.state.info).then(() => {
            $('.is-info').show();
            $('.js-info-loader').hide();
            this.props.setNotification({ message: CONSTANTS.USER_INFO_CHANGED, type: 'success' });
          }, (error) => {
            $('.is-info').show();
            $('.js-info-loader').hide();
            this.props.setNotification({ message: String(error), type: 'error' });
          });
        }, (error) => {
          $('.is-info').show();
          $('.js-info-loader').hide();
          this.props.setNotification({ message: String(error), type: 'error' });
        });
        /* console.log('snapshot ', snapshot.metadata.downloadURL);
*/
      }, (error) => {
        $('.is-info').show();
        $('.js-info-loader').hide();
        this.props.setNotification({ message: String(error), type: 'error' });
      });
    }
  }

  handleChange(event) {
    console.log('event ', event.target);
    const newInfo = Object.assign({}, this.state.info, {
      [event.target.name]: event.target.value
    });
    this.setState({ info: newInfo });
  }

  displayPicture(event) {
    const reader = new window.FileReader();
    const file = event.target.files[0];
    reader.onloadend = () => {
      this.setState({
        picture: file,
        pictureUrl: reader.result
      });
    };
    reader.readAsDataURL(file);
  }

  render() {
    return (
      <section className="account account-settings page">
        {(this.props.user && this.props.userData && this.state.info)
          ? <div className="column is-8">
            <h1 className="title is-3">Settings</h1>
            <h2 className="subtitle is-5">
              General information about your Alien account
              </h2>
            <div id="profile" className="m-b-md">
              <div className="card">
                <header className="card-header">
                  <p className="card-header-title">Profile Info</p>
                </header>
                <div className="card-content">
                  <div className="columns">
                    <div className="column is-two-thirds">
                      <div className="field field-name">
                        <label className="label">First Name</label>
                        <p className="control has-icons-right has-icons-left">
                          <input
                            id="firstName"
                            name="firstName"
                            type="text"
                            autoComplete="off"
                            className="input  "
                            value={this.state.info.firstName}
                            onChange={this.handleChange}
                          />
                          <span className="icon is-small is-left">
                            <svg
                              aria-hidden="true"
                              data-prefix="fal"
                              data-icon="user-graduate"
                              className="svg-inline--fa fa-user-graduate fa-w-14 fa-fw "
                              role="img"
                              xmlns="http://www.w3.org/2000/svg"
                              viewBox="0 0 448 512"
                            >
                              <path
                                fill="currentColor"
                                d="M319.4 320.6L224 400l-95.4-79.4C110.2 321.4 0 336.1 0 464c0 26.5 21.5 48 48 48h352c26.5 0 48-21.5 48-48 0-127.9-110.1-142.6-128.6-143.4zM208 480H48c-8.8 0-16-7.2-16-16 0-99.6 84.1-109.9 86.4-110.3l89.6 74.6V480zm208-16c0 8.8-7.2 16-16 16H240v-51.7l89.6-74.6c2.3.4 86.4 10.7 86.4 110.3zM13.2 100l6.8 2v37.6c-7 4.2-12 11.5-12 20.3 0 8.4 4.6 15.4 11.1 19.7L3.5 242c-1.7 6.9 2.1 14 7.6 14h41.8c5.5 0 9.3-7.1 7.6-14l-15.6-62.3C51.4 175.4 56 168.4 56 160c0-8.8-5-16.1-12-20.3v-30.5L90.7 123C84 139.4 80 157.2 80 176c0 79.5 64.5 144 144 144s144-64.5 144-144c0-18.8-4-36.6-10.7-53l77.5-23c17.6-5.2 17.6-34.8 0-40L240.9 2.5C235.3.8 229.7 0 224 0s-11.3.8-16.9 2.5L13.2 60c-17.6 5.2-17.6 34.8 0 40zM224 288c-61.8 0-112-50.2-112-112 0-15.7 3.7-30.3 9.6-43.8l85.5 25.4c14.8 4.4 27.2 2 33.8 0l85.5-25.4c5.9 13.5 9.6 28.2 9.6 43.8 0 61.8-50.2 112-112 112zm-7.8-254.9c.8-.2 7.3-2.4 15.6 0l158 46.9-158 46.9c-.8.2-7.3 2.4-15.6 0L58.2 80l158-46.9z"
                              />
                            </svg>
                          </span>
                        </p>
                      </div>
                      <div className="field field-name">
                        <label className="label">Last Name</label>
                        <p className="control has-icons-right has-icons-left">
                          <input
                            id="lastName"
                            name="lastName1"
                            type="text"
                            autoComplete="off"
                            className="input  "
                            value={this.state.info.lastName1}
                            onChange={this.handleChange}
                          />
                          <span className="icon is-small is-left">
                            <svg
                              aria-hidden="true"
                              data-prefix="fal"
                              data-icon="user-graduate"
                              className="svg-inline--fa fa-user-graduate fa-w-14 fa-fw "
                              role="img"
                              xmlns="http://www.w3.org/2000/svg"
                              viewBox="0 0 448 512"
                            >
                              <path
                                fill="currentColor"
                                d="M319.4 320.6L224 400l-95.4-79.4C110.2 321.4 0 336.1 0 464c0 26.5 21.5 48 48 48h352c26.5 0 48-21.5 48-48 0-127.9-110.1-142.6-128.6-143.4zM208 480H48c-8.8 0-16-7.2-16-16 0-99.6 84.1-109.9 86.4-110.3l89.6 74.6V480zm208-16c0 8.8-7.2 16-16 16H240v-51.7l89.6-74.6c2.3.4 86.4 10.7 86.4 110.3zM13.2 100l6.8 2v37.6c-7 4.2-12 11.5-12 20.3 0 8.4 4.6 15.4 11.1 19.7L3.5 242c-1.7 6.9 2.1 14 7.6 14h41.8c5.5 0 9.3-7.1 7.6-14l-15.6-62.3C51.4 175.4 56 168.4 56 160c0-8.8-5-16.1-12-20.3v-30.5L90.7 123C84 139.4 80 157.2 80 176c0 79.5 64.5 144 144 144s144-64.5 144-144c0-18.8-4-36.6-10.7-53l77.5-23c17.6-5.2 17.6-34.8 0-40L240.9 2.5C235.3.8 229.7 0 224 0s-11.3.8-16.9 2.5L13.2 60c-17.6 5.2-17.6 34.8 0 40zM224 288c-61.8 0-112-50.2-112-112 0-15.7 3.7-30.3 9.6-43.8l85.5 25.4c14.8 4.4 27.2 2 33.8 0l85.5-25.4c5.9 13.5 9.6 28.2 9.6 43.8 0 61.8-50.2 112-112 112zm-7.8-254.9c.8-.2 7.3-2.4 15.6 0l158 46.9-158 46.9c-.8.2-7.3 2.4-15.6 0L58.2 80l158-46.9z"
                              />
                            </svg>
                          </span>
                        </p>
                      </div>
                      <div className="field field-username">
                        <label className="label">Display Name</label>
                        <p className="control has-icons-right has-icons-left">
                          <input
                            id="username"
                            name="displayName"
                            type="text"
                            autoComplete="off"
                            className="input  "
                            value={this.state.info.displayName}
                            onChange={this.handleChange}
                          />
                          <span className="icon is-small is-left">
                            <svg
                              aria-hidden="true"
                              data-prefix="fal"
                              data-icon="at"
                              className="svg-inline--fa fa-at fa-w-16 fa-fw "
                              role="img"
                              xmlns="http://www.w3.org/2000/svg"
                              viewBox="0 0 512 512"
                            >
                              <path
                                fill="currentColor"
                                d="M256 8C118.941 8 8 118.919 8 256c0 137.058 110.919 248 248 248 52.925 0 104.68-17.078 147.092-48.319 5.501-4.052 6.423-11.924 2.095-17.211l-5.074-6.198c-4.018-4.909-11.193-5.883-16.307-2.129C346.93 457.208 301.974 472 256 472c-119.373 0-216-96.607-216-216 0-119.375 96.607-216 216-216 118.445 0 216 80.024 216 200 0 72.873-52.819 108.241-116.065 108.241-19.734 0-23.695-10.816-19.503-33.868l32.07-164.071c1.449-7.411-4.226-14.302-11.777-14.302h-12.421a12 12 0 0 0-11.781 9.718c-2.294 11.846-2.86 13.464-3.861 25.647-11.729-27.078-38.639-43.023-73.375-43.023-68.044 0-133.176 62.95-133.176 157.027 0 61.587 33.915 98.354 90.723 98.354 39.729 0 70.601-24.278 86.633-46.982-1.211 27.786 17.455 42.213 45.975 42.213C453.089 378.954 504 321.729 504 240 504 103.814 393.863 8 256 8zm-37.92 342.627c-36.681 0-58.58-25.108-58.58-67.166 0-74.69 50.765-121.545 97.217-121.545 38.857 0 58.102 27.79 58.102 65.735 0 58.133-38.369 122.976-96.739 122.976z"
                              />
                            </svg>
                          </span>
                        </p>
                      </div>
                      <div className="field field-email">
                        <label className="label">Email</label>
                        <p className="control has-icons-right has-icons-left">
                          <input
                            id="email"
                            name="email"
                            type="email"
                            autoComplete="off"
                            className="input  "
                            value={this.state.info.email}
                            disabled
                          />
                          <span className="icon is-small is-left">
                            <svg
                              aria-hidden="true"
                              data-prefix="fal"
                              data-icon="envelope"
                              className="svg-inline--fa fa-envelope fa-w-16 fa-fw "
                              role="img"
                              xmlns="http://www.w3.org/2000/svg"
                              viewBox="0 0 512 512"
                            >
                              <path
                                fill="currentColor"
                                d="M464 64H48C21.5 64 0 85.5 0 112v288c0 26.5 21.5 48 48 48h416c26.5 0 48-21.5 48-48V112c0-26.5-21.5-48-48-48zM48 96h416c8.8 0 16 7.2 16 16v41.4c-21.9 18.5-53.2 44-150.6 121.3-16.9 13.4-50.2 45.7-73.4 45.3-23.2.4-56.6-31.9-73.4-45.3C85.2 197.4 53.9 171.9 32 153.4V112c0-8.8 7.2-16 16-16zm416 320H48c-8.8 0-16-7.2-16-16V195c22.8 18.7 58.8 47.6 130.7 104.7 20.5 16.4 56.7 52.5 93.3 52.3 36.4.3 72.3-35.5 93.3-52.3 71.9-57.1 107.9-86 130.7-104.7v205c0 8.8-7.2 16-16 16z"
                              />
                            </svg>
                          </span>
                        </p>
                      </div>
                      <div className="field">
                        <label className="label">Bio</label>
                        <textarea
                          name="bio"
                          id="bio"
                          rows={4}
                          maxLength={250}
                          className="textarea"
                          value={this.state.info.bio}
                          onChange={this.handleChange}
                        />
                      </div>
                      <div className="field field-website">
                        <label className="label">Website</label>
                        <p className="control has-icons-right has-icons-left">
                          <input
                            id="website"
                            name="website"
                            type="text"
                            autoComplete="off"
                            className="input  "
                            value={this.state.info.website}
                            onChange={this.handleChange}
                          />
                          <span className="icon is-small is-left">
                            <svg
                              aria-hidden="true"
                              data-prefix="fal"
                              data-icon="link"
                              className="svg-inline--fa fa-link fa-w-16 fa-fw "
                              role="img"
                              xmlns="http://www.w3.org/2000/svg"
                              viewBox="0 0 512 512"
                            >
                              <path
                                fill="currentColor"
                                d="M301.148 394.702l-79.2 79.19c-50.778 50.799-133.037 50.824-183.84 0-50.799-50.778-50.824-133.037 0-183.84l79.19-79.2a132.833 132.833 0 0 1 3.532-3.403c7.55-7.005 19.795-2.004 20.208 8.286.193 4.807.598 9.607 1.216 14.384.481 3.717-.746 7.447-3.397 10.096-16.48 16.469-75.142 75.128-75.3 75.286-36.738 36.759-36.731 96.188 0 132.94 36.759 36.738 96.188 36.731 132.94 0l79.2-79.2.36-.36c36.301-36.672 36.14-96.07-.37-132.58-8.214-8.214-17.577-14.58-27.585-19.109-4.566-2.066-7.426-6.667-7.134-11.67a62.197 62.197 0 0 1 2.826-15.259c2.103-6.601 9.531-9.961 15.919-7.28 15.073 6.324 29.187 15.62 41.435 27.868 50.688 50.689 50.679 133.17 0 183.851zm-90.296-93.554c12.248 12.248 26.362 21.544 41.435 27.868 6.388 2.68 13.816-.68 15.919-7.28a62.197 62.197 0 0 0 2.826-15.259c.292-5.003-2.569-9.604-7.134-11.67-10.008-4.528-19.371-10.894-27.585-19.109-36.51-36.51-36.671-95.908-.37-132.58l.36-.36 79.2-79.2c36.752-36.731 96.181-36.738 132.94 0 36.731 36.752 36.738 96.181 0 132.94-.157.157-58.819 58.817-75.3 75.286-2.651 2.65-3.878 6.379-3.397 10.096a163.156 163.156 0 0 1 1.216 14.384c.413 10.291 12.659 15.291 20.208 8.286a131.324 131.324 0 0 0 3.532-3.403l79.19-79.2c50.824-50.803 50.799-133.062 0-183.84-50.802-50.824-133.062-50.799-183.84 0l-79.2 79.19c-50.679 50.682-50.688 133.163 0 183.851z"
                              />
                            </svg>
                          </span>
                        </p>
                      </div>
                      <div className="field field-twitter_username">
                        <label className="label">Twitter Username</label>
                        <p className="control has-icons-right has-icons-left">
                          <input
                            id="twitter_username"
                            name="twitterUsername"
                            type="text"
                            autoComplete="off"
                            className="input  "
                            value={this.state.twitter}
                            onChange={this.handleChange}
                          />
                          <span className="icon is-small is-left">
                            <svg
                              aria-hidden="true"
                              data-prefix="fal"
                              data-icon="at"
                              className="svg-inline--fa fa-at fa-w-16 fa-fw "
                              role="img"
                              xmlns="http://www.w3.org/2000/svg"
                              viewBox="0 0 512 512"
                            >
                              <path
                                fill="currentColor"
                                d="M256 8C118.941 8 8 118.919 8 256c0 137.058 110.919 248 248 248 52.925 0 104.68-17.078 147.092-48.319 5.501-4.052 6.423-11.924 2.095-17.211l-5.074-6.198c-4.018-4.909-11.193-5.883-16.307-2.129C346.93 457.208 301.974 472 256 472c-119.373 0-216-96.607-216-216 0-119.375 96.607-216 216-216 118.445 0 216 80.024 216 200 0 72.873-52.819 108.241-116.065 108.241-19.734 0-23.695-10.816-19.503-33.868l32.07-164.071c1.449-7.411-4.226-14.302-11.777-14.302h-12.421a12 12 0 0 0-11.781 9.718c-2.294 11.846-2.86 13.464-3.861 25.647-11.729-27.078-38.639-43.023-73.375-43.023-68.044 0-133.176 62.95-133.176 157.027 0 61.587 33.915 98.354 90.723 98.354 39.729 0 70.601-24.278 86.633-46.982-1.211 27.786 17.455 42.213 45.975 42.213C453.089 378.954 504 321.729 504 240 504 103.814 393.863 8 256 8zm-37.92 342.627c-36.681 0-58.58-25.108-58.58-67.166 0-74.69 50.765-121.545 97.217-121.545 38.857 0 58.102 27.79 58.102 65.735 0 58.133-38.369 122.976-96.739 122.976z"
                              />
                            </svg>
                          </span>
                        </p>
                      </div>

                      <div className="field field-instagram_username">
                        <label className="label">Instagram Username</label>
                        <p className="control has-icons-right has-icons-left">
                          <input
                            id="instagram_username"
                            name="instagramUsername"
                            type="text"
                            autoComplete="off"
                            className="input  "
                            value={this.state.info.instagram}
                            onChange={this.handleChange}
                          />
                          <span className="icon is-small is-left">
                            <svg
                              aria-hidden="true"
                              data-prefix="fal"
                              data-icon="at"
                              className="svg-inline--fa fa-at fa-w-16 fa-fw "
                              role="img"
                              xmlns="http://www.w3.org/2000/svg"
                              viewBox="0 0 512 512"
                            >
                              <path
                                fill="currentColor"
                                d="M256 8C118.941 8 8 118.919 8 256c0 137.058 110.919 248 248 248 52.925 0 104.68-17.078 147.092-48.319 5.501-4.052 6.423-11.924 2.095-17.211l-5.074-6.198c-4.018-4.909-11.193-5.883-16.307-2.129C346.93 457.208 301.974 472 256 472c-119.373 0-216-96.607-216-216 0-119.375 96.607-216 216-216 118.445 0 216 80.024 216 200 0 72.873-52.819 108.241-116.065 108.241-19.734 0-23.695-10.816-19.503-33.868l32.07-164.071c1.449-7.411-4.226-14.302-11.777-14.302h-12.421a12 12 0 0 0-11.781 9.718c-2.294 11.846-2.86 13.464-3.861 25.647-11.729-27.078-38.639-43.023-73.375-43.023-68.044 0-133.176 62.95-133.176 157.027 0 61.587 33.915 98.354 90.723 98.354 39.729 0 70.601-24.278 86.633-46.982-1.211 27.786 17.455 42.213 45.975 42.213C453.089 378.954 504 321.729 504 240 504 103.814 393.863 8 256 8zm-37.92 342.627c-36.681 0-58.58-25.108-58.58-67.166 0-74.69 50.765-121.545 97.217-121.545 38.857 0 58.102 27.79 58.102 65.735 0 58.133-38.369 122.976-96.739 122.976z"
                              />
                            </svg>
                          </span>
                        </p>
                      </div>
                      <div className="field field-facebook_username">
                        <label className="label">Facebook Username</label>
                        <p className="control has-icons-right has-icons-left">
                          <input
                            id="facebook_username"
                            name="facebookUsername"
                            type="text"
                            autoComplete="off"
                            className="input  "
                            value={this.state.info.facebook}
                            onChange={this.handleChange}
                          />
                          <span className="icon is-small is-left">
                            <svg
                              aria-hidden="true"
                              data-prefix="fal"
                              data-icon="at"
                              className="svg-inline--fa fa-at fa-w-16 fa-fw "
                              role="img"
                              xmlns="http://www.w3.org/2000/svg"
                              viewBox="0 0 512 512"
                            >
                              <path
                                fill="currentColor"
                                d="M256 8C118.941 8 8 118.919 8 256c0 137.058 110.919 248 248 248 52.925 0 104.68-17.078 147.092-48.319 5.501-4.052 6.423-11.924 2.095-17.211l-5.074-6.198c-4.018-4.909-11.193-5.883-16.307-2.129C346.93 457.208 301.974 472 256 472c-119.373 0-216-96.607-216-216 0-119.375 96.607-216 216-216 118.445 0 216 80.024 216 200 0 72.873-52.819 108.241-116.065 108.241-19.734 0-23.695-10.816-19.503-33.868l32.07-164.071c1.449-7.411-4.226-14.302-11.777-14.302h-12.421a12 12 0 0 0-11.781 9.718c-2.294 11.846-2.86 13.464-3.861 25.647-11.729-27.078-38.639-43.023-73.375-43.023-68.044 0-133.176 62.95-133.176 157.027 0 61.587 33.915 98.354 90.723 98.354 39.729 0 70.601-24.278 86.633-46.982-1.211 27.786 17.455 42.213 45.975 42.213C453.089 378.954 504 321.729 504 240 504 103.814 393.863 8 256 8zm-37.92 342.627c-36.681 0-58.58-25.108-58.58-67.166 0-74.69 50.765-121.545 97.217-121.545 38.857 0 58.102 27.79 58.102 65.735 0 58.133-38.369 122.976-96.739 122.976z"
                              />
                            </svg>
                          </span>
                        </p>
                      </div>
                    </div>
                    <div className="column is-one-third">
                      <div
                        className="dropzone has-text-centered  has-image"
                        aria-disabled="false"
                        style={{
                          position: 'relative'
                        }}
                      >
                        <input
                          className="input "
                          accept="image/*"
                          type="file"
                          name="profileImage"
                          multiple
                          autoComplete="off"
                          onChange={(event) => {
                            this.displayPicture(event);
                          }}
                        />
                        <img
                          className="image-placeholder"
                          src={this.state.pictureUrl || this.state.info.profilePicture}
                          alt="Preview"
                        />

                      </div>
                    </div>
                  </div>
                </div>
                <footer className="card-footer">
                  <div
                    className="card-footer-item p-a"
                    style={{
                      justifyContent: 'flex-end'
                    }}
                  >
                    <button
                      className="button is-info"
                      style={{
                        minHeight: '30px'
                      }}
                      onClick={() => this.updateUserInfo()}
                    >
                      Update Profile
                        </button>
                    <div className="loader-small float-right js-info-loader" />
                  </div>
                </footer>
              </div>
              <div className="notifications-wrapper" />
            </div>
            <div id="notifications" className="m-b-md">
              <div className="card">
                <header className="card-header">
                  <p className="card-header-title">Email Settings</p>
                </header>
                <div className="card-content">
                  <div className="columns">
                    <div className="column is-6">
                      <h5 className="title is-6 m-b-xs">
                        Analytics notifications
                          </h5>
                      <p>Pageviews, readers, and more info about your posts.</p>
                    </div>
                    <div className="column has-text-right center-flex-v">
                      <div>
                        <label className="checkbox m-r-sm">
                          <input
                            type="checkbox"
                            className="m-r-xs"
                            id="gets_weekly_stats"
                            name="gets_weekly_stats"
                          />
                          Weekly
                            </label>
                        <label className="checkbox">
                          <input
                            type="checkbox"
                            className="m-r-xs"
                            id="gets_monthly_stats"
                            name="gets_monthly_stats"
                          />
                          Monthly
                            </label>
                      </div>
                    </div>
                  </div>
                  <div className="columns">
                    <div className="column is-6">
                      <h5 className="title is-6 m-b-xs">Comment notifications</h5>
                      <p>Find out when people are commenting on your content.</p>
                    </div>
                    <div className="column has-text-right center-flex-v">
                      <div>
                        <label className="checkbox m-r-sm">
                          <input
                            type="checkbox"
                            className="m-r-xs"
                            id="gets_hourly_comments"
                            name="gets_hourly_comments"
                          />
                          Immediate-ish-ly
                            </label>
                        <label className="checkbox m-r-sm">
                          <input
                            type="checkbox"
                            className="m-r-xs"
                            id="gets_daily_comments"
                            name="gets_daily_comments"
                          />
                          Daily
                            </label>
                        <label className="checkbox m-r-sm">
                          <input
                            type="checkbox"
                            className="m-r-xs"
                            id="gets_weekly_comments"
                            name="gets_weekly_comments"
                          />
                          Weekly
                            </label>
                      </div>
                    </div>
                  </div>
                </div>
                <footer className="card-footer">
                  <div
                    className="card-footer-item p-a"
                    style={{
                      justifyContent: 'flex-end'
                    }}
                  >
                    <button
                      className="button is-info"
                      style={{
                        minHeight: '30px'
                      }}
                      disabled
                    >
                      Update Notifications
                        </button>
                  </div>
                </footer>
              </div>
              <div className="notifications-wrapper" />
            </div>
            <div id="password" className="m-b-md">
              <div className="card">
                <header className="card-header">
                  <p className="card-header-title">Update Your Password</p>
                </header>
                <div className="card-content">
                  <div className="field field-password">
                    <label className="label">Password</label>
                    <p className="control has-icons-right has-icons-left">
                      <input
                        id="password"
                        name="password"
                        type="password"
                        autoComplete="off"
                        className="input  "
                        value={this.state.password}
                        aria-autocomplete="list"
                      />
                      <span className="icon is-small is-left">
                        <svg
                          aria-hidden="true"
                          data-prefix="fal"
                          data-icon="asterisk"
                          className="svg-inline--fa fa-asterisk fa-w-16 fa-fw "
                          role="img"
                          xmlns="http://www.w3.org/2000/svg"
                          viewBox="0 0 512 512"
                        >
                          <path
                            fill="currentColor"
                            d="M475.31 364.144L288 256l187.31-108.144c5.74-3.314 7.706-10.653 4.392-16.392l-4-6.928c-3.314-5.74-10.653-7.706-16.392-4.392L272 228.287V12c0-6.627-5.373-12-12-12h-8c-6.627 0-12 5.373-12 12v216.287L52.69 120.144c-5.74-3.314-13.079-1.347-16.392 4.392l-4 6.928c-3.314 5.74-1.347 13.079 4.392 16.392L224 256 36.69 364.144c-5.74 3.314-7.706 10.653-4.392 16.392l4 6.928c3.314 5.74 10.653 7.706 16.392 4.392L240 283.713V500c0 6.627 5.373 12 12 12h8c6.627 0 12-5.373 12-12V283.713l187.31 108.143c5.74 3.314 13.079 1.347 16.392-4.392l4-6.928c3.314-5.74 1.347-13.079-4.392-16.392z"
                          />
                        </svg>
                      </span>
                    </p>
                  </div>
                  <div className="field field-password_confirmation">
                    <label className="label">Password Confirmation</label>
                    <p className="control has-icons-right has-icons-left">
                      <input
                        id="password_confirmation"
                        name="password_confirmation"
                        type="password"
                        autoComplete="off"
                        className="input  "
                        value={this.state.password2}
                      />
                      <span className="icon is-small is-left">
                        <svg
                          aria-hidden="true"
                          data-prefix="fal"
                          data-icon="asterisk"
                          className="svg-inline--fa fa-asterisk fa-w-16 fa-fw "
                          role="img"
                          xmlns="http://www.w3.org/2000/svg"
                          viewBox="0 0 512 512"
                        >
                          <path
                            fill="currentColor"
                            d="M475.31 364.144L288 256l187.31-108.144c5.74-3.314 7.706-10.653 4.392-16.392l-4-6.928c-3.314-5.74-10.653-7.706-16.392-4.392L272 228.287V12c0-6.627-5.373-12-12-12h-8c-6.627 0-12 5.373-12 12v216.287L52.69 120.144c-5.74-3.314-13.079-1.347-16.392 4.392l-4 6.928c-3.314 5.74-1.347 13.079 4.392 16.392L224 256 36.69 364.144c-5.74 3.314-7.706 10.653-4.392 16.392l4 6.928c3.314 5.74 10.653 7.706 16.392 4.392L240 283.713V500c0 6.627 5.373 12 12 12h8c6.627 0 12-5.373 12-12V283.713l187.31 108.143c5.74 3.314 13.079 1.347 16.392-4.392l4-6.928c3.314-5.74 1.347-13.079-4.392-16.392z"
                          />
                        </svg>
                      </span>
                    </p>
                  </div>
                </div>
                <footer className="card-footer">
                  <div
                    className="card-footer-item p-a"
                    style={{
                      justifyContent: 'flex-end'
                    }}
                  >
                    <button
                      onClick={() => this.updatePassword()}
                      className="button is-info"
                      style={{
                        minHeight: '30px'
                      }}
                    >
                      Update Password
                        </button>
                    <div className="loader-small float-right js-password-loader" />

                  </div>
                </footer>
              </div>
              <div className="notifications-wrapper" />
            </div>
            <div className="lazyload-placeholder" />
          </div>
          : <div className="loader-small" />}
      </section>
    );
  }
}

const mapDispatchToProps = {
  setLoading,
  setNotification,
  setUser,
  setUserData
};

const mapStateToProps = ({
  mainReducer: {
    user,
    userData
  }
}) => ({ user, userData });

export default connect(mapStateToProps, mapDispatchToProps)(Settings);
