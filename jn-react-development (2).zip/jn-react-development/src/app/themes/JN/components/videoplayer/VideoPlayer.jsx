import React, { Component } from 'react';

const iframeStyle = {
  position: 'absolute',
  top: '0',
  left: '0',
  width: '100%',
  height: '100%'
};
const divStyle = {
  padding: '56.25% 0 0 0',
  position: 'relative'
};
class VideoPlayer extends Component {


  constructor(props) {
    super(props);
    this.props = props;
  }
  render() {
    return (
      <div style={divStyle}>
        <iframe
          style={iframeStyle}
          src={`https://player.vimeo.com/video/${this.props.id}`}
/*           webkitAllowFullScreen
          mozAllowFullScreen */
          allowFullScreen
          frameBorder="0"
        />
      </div>
    );
  }
 }


export default VideoPlayer;
