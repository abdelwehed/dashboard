import React, { Component } from 'react';

import _ from 'lodash';
import { firebaseConnect, populate, getVal, isLoaded, isEmpty } from 'react-redux-firebase/lib';
import { connect } from 'react-redux';
import { compose } from 'redux';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import PropTypes from 'prop-types';
import { Link } from 'react-router';
// import JnLessonList from '../jnlessonsList/jnlessonlist';
import Helpers from '../../../../core/common/helpers';
import { databaseRef } from '../../../../store';

class JnLessonList extends Component {
  constructor(props, children) {
    super(props);
    this.toggleBlocking = this.toggleBlocking.bind(this);
    this.state = {
      userData: null,
      courseData: null,
      lessons: null,
      lessonsData: null,
      position: 0
    };
  }
  componentWillMount() {
   /*  if (!_.isEmpty(this.props.userData) && _.isEmpty(this.props.lessonsData)) {
     // console.log('component will mount !!!!!!!', Object.keys(this.props.courseData)[0]);
      this.props.fetchlessons('course', Object.keys(this.props.courseData)[0]);
    } else if (_.isEmpty(this.props.lessonsData) && Object.values(this.props.lessonsData)[0].course !== Object.key(this.props.courseData)[0]) {
      this.props.fetchlessons('course', Object.keys(this.props.courseData)[0]);
    } */
    this.setState({
      userData: this.props.userData.info,
      courseData: this.props.courseData,
      lessons: this.props.lessons,
      lessonsData: this.props.lessonsData,
      position: this.props.position
    });
  }
  // eslint-disable-next-line class-methods-use-this
  toggleBlocking() {
    // this.setState({ blocking: !this.state.blocking });
    /* databaseRef.child('/lessons').orderByChild('course').equalTo(Object.keys(this.props.course)[0]).once('value')
      .then((snapshot) => {
        console.log('lessonsssss ', snapshot.val());
      })
      .catch(err => console.log('errr ', err.code)); */
    this.props.fetchlessons('course', Object.keys(this.props.courseData)[0]);
   // console.log('prps ', this.props.fetchlessons('course', Object.keys(this.props.course)[0]));
    // list = (<ReactLessonList userData={this.props.userData.info} course={this.props.course} lessons={lessons} position={currentcourse} />);
  }

  render() {
    console.log('prps ', this.props);
    return (
      <div>
        <div id="react-lesson-list" >
          {/* this.props.lessonsData ? <JnLessonList {...this.props} /> : <div /> */}
          <LessonList {...this.props} />
        </div>
        <input className="button" type="button" value="Click me" onClick={this.toggleBlocking} />
      </div>
    );
  }
}
function LessonList(props) {
  // const courseId = Object.keys(props.courseData)[0];
  const lessons = props.courseData[0].value.lessons;
  // const userCourses = props.userData.courses || [];
   // TODO implement react-block-ui in the lessons list to check if the user have the course id or he must buy it
  console.log('user courses ', props.courseData[0].value.lessons);
   // console.log('lessons lis ', helpers.checkUserCourses(userCourses, courseId));

  const groupedLessons = _.groupBy(lessons, 'lesson_group');
   // console.log('lessons lis ', props.userData);

  const listItems = Object.keys(groupedLessons).map((key) => {
    const items = groupedLessons[key];
    return (
      <div key={key}>
        <div className="jn-list-header lesson-list-header" >{key}</div>
        {
           // eslint-disable-next-line arrow-body-style
           items.map((item) => {
             const selected = item.position === props.position ? 'is-current' : 'non';

             return (<Link key={item.position} className={`jn-list-item lesson ${selected}`} to={`/courses/${props.courseData[0].value.slug}/${item.slug}`} alt={item.title}>
               <div>
                 <span className="position">{item.position}</span>
                 <span className="text">{item.title}</span>
               </div>
               <div className="lesson-actions" ><span className="duration">{item.video_length}</span></div></Link>);
           })
           }

      </div>
    );
  });
  const lessoncount = Object.keys(lessons).length;
  const lessoncontent = props.position === 0 ? 'Start this course' : 'Next lesson';
  let position = props.position === 0 ? 0 : props.position;
  console.log('position 1', props.position);

  position = position > lessoncount ? lessoncount : position;
  console.log('position 2', position);

   // console.log('position ', position);
  const header = position === lessoncount ? (<div />) :
     (
       <Link to={`/courses/${props.courseData[0].value.slug}/${Object.values(lessons)[position].slug}`} className="lesson is-giant center-flex" >
         <div id="DIV_5">
           <FontAwesomeIcon size="3x" icon="file" />
           <div className="lesson-context" id="DIV_8">{lessoncontent}</div>
           <h5 className="title is-5" id="H5_9">{Object.values(lessons)[position].title}</h5></div></Link>
     );
  return (

    <div className="jn-list lesson-list">
      <div className="jn-list-meta lesson-list-meta">
        <h5 className="title">{lessoncount} Lessons</h5>
      </div>
      {header}
      {listItems}
    </div>
  );
}


const fire = firebaseConnect(props => [
  // { path: '/courses/featuredImage', storeAs: 'img' },
  { type: 'once', path: '/lessons', queryParams: ['orderByChild=course', 'equalTo=K_yehssjdhjrjd'] }
  // { path: '/courses' }
]);

const con = connect(state => ({
  lessonsData: state.firebase.data.lessons
  // profile: state.firebase.profile // load profile
}));

export default compose(con, fire)(JnLessonList);
