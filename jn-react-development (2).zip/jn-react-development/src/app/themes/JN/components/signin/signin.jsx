import React, { Component } from 'react';
import { connect } from 'react-redux';
import $ from 'jquery';
import firebase from 'firebase';
import { setNotification } from '../../../../core/actions/actions';
import { USER_CONFIRM_EMAIL, PASSWORD_MATCH_ERROR } from '../../../../core/constants/constants';

class Signup extends Component {

  constructor(props) {
    super(props);


    this.handleSignin = this.handleSignin.bind(this);
  }
  handleSignup(e) {
    e.preventDefault();

    const { password, password2, firstname, lastname } = this.refs;

    if (password.value === password2.value) {
      $('.js-btn-signup').hide();
      $('.js-signup-loader').show();

      const email = String(this.refs.email.value);

      firebase.auth().createUserWithEmailAndPassword(email, password.value).then((user) => {
        this.saveUser(firebase.auth().currentUser, firstname.value, lastname.value, email);
      }).catch((error) => {
        $('.js-btn-signup').show();
        $('.js-signup-loader').hide();
        this.props.setNotification({ message: String(error), type: 'error' });
      });
    } else {
      this.props.setNotification({ message: PASSWORD_MATCH_ERROR, type: 'error' });
    }
  }

  saveUser(user, firstname, lastname, email) {
    return firebase.database().ref(`users/${user.uid}/info`).set({
      firstName: firstname,
      lastName1: lastname,
      email,
      displayName: `${firstname} ${lastname}`
    }).then(() => {
      this.sendVerificationMail();
      $('.js-btn-signup').show();
      $('.js-signup-loader').hide();
      $('.js-overlay').click();
    })
    .catch((error) => {
      $('.js-btn-signup').show();
      $('.js-signup-loader').hide();
      this.props.setNotification({ message: String(error), type: 'error' });
    });
  }

  // eslint-disable-next-line class-methods-use-this
  sendVerificationMail() {
    firebase.auth().currentUser.sendEmailVerification()
    .then(() => {
      // Verification email sent.
      this.props.setNotification({ message: USER_CONFIRM_EMAIL, type: 'success' });
    })
    .catch((error) => {
      // Error occurred. Inspect error.code.
      this.props.setNotification({ message: String(error), type: 'error' });
    });
  }


  resetPwd() {
    // e.preventDefault();
    $('.js-btn-signin').hide();
    $('.js-signin-loader').show();
    $('.js-btn-reset').hide();
    firebase.auth().sendPasswordResetEmail(this.refs.email.value).then(() => {
      // Email sent.
      this.props.setNotification({ message: 'Reset mail has been sent', type: 'info' });
    }).catch((error) => {
      // An error happened.
      $('.js-btn-reset').show();
      this.props.setNotification({ message: String(error), type: 'error' });
    });
  }

  handleSignin(e) {
    e.preventDefault();
    $('.js-btn-signin').hide();
    $('.js-signin-loader').show();

    const email = String(this.refs.email.value);
    const { password } = this.refs;

    firebase.auth().signInWithEmailAndPassword(email, password.value).then(() => {
      $('.js-btn-signin').show();
      $('.js-signin-loader').hide();
      $('.js-overlay').click();
    }).catch((error) => {
      $('.js-btn-signin').show();
      $('.js-signin-loader').hide();
      const errorCode = error.code;
      if (errorCode === 'auth/wrong-password') {
        $('.js-btn-reset').show();
        this.props.setNotification({ message: 'Wrong email or password', type: 'error' });
      } else {
        this.props.setNotification({ message: String(error), type: 'error' });
      }
    });
  }

  render() {
    return (
      <form className="user-form sign-in" onSubmit={this.handleSignin}>
        <input type="text" className="input-field" ref="email" placeholder="Email" />
        <input type="password" className="input-field" placeholder="Password" ref="password" />
        <button type="submit" className="btn btn-primary js-btn-signin">Sign in</button>
        <button className="btn btn-primary js-btn-reset" onClick={() => this.resetPwd()} >Reset PWD</button>

        <div className="loader-small js-signin-loader" />
      </form>
    );
  }
}

const mapStateToProps = null;

const mapDispatchToProps = {
  setNotification
};

export default connect(mapStateToProps, mapDispatchToProps)(Signup);
